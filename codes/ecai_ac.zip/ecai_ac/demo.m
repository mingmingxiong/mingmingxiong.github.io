load sonar2.mat

[errt,qryt] = ActiveClustering_ecai(dist_sonar, la_sonar,2,1);