function [N_p,h,ML,CL] = Consolidate_single_W(distW,labels,old_N_p,ind)

%assume the length of N_p is the number of clusters after Explore step

%data: n x d
%labels: n x 1
%old_N_p: Neighborhoods
%Q: allowed number of queries

%N_p: new Neighborhoods
ML = [];
CL = [];
num = length(old_N_p);
dist = zeros(num, 1);
N_p = old_N_p;
wholeP = [];
for i = 1:length(old_N_p)
    dist(i) = min(distW(old_N_p(i).elements,ind));
end
nCluster = length(unique(labels));
    
    [v,d] = sort(dist,'ascend');
    bfind = -1;
    for h = 1:num
        if labels(ind) == labels(N_p(d(h)).elements(1))
            N_p(d(h)).elements = [N_p(d(h)).elements ind];
            wholeP = [ wholeP ind];
            bfind = 1;
            break;
        end
    end
    
    if h == nCluster && bfind == 1
        h = num - 1;
    end
    
    if bfind == -1
        temp = struct;
        temp.elements = ind;
        N_p = [N_p; temp];
    end

    
for h1 = 1:num
        if labels(ind) == labels(N_p(d(h1)).elements(1))
            wholeP = N_p(d(h1)).elements;
            for i = 1:length(wholeP)
                ML = [ML; [wholeP(i) ind]];
            end
        else
            wholeP = N_p(d(h1)).elements;
            for i = 1:length(wholeP)
                CL = [CL; [wholeP(i) ind]];
            end            
        end
end