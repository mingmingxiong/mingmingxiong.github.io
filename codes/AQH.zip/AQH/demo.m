load labelme_PCA_32.mat  % the labelme dataset with the first 32 projections by PCA
bit = 32; %64

[m,d] = size(XX);
XX = XX(randperm(m),:);%%%
X_te = XX(1:1000,:);
X_tr = XX(1001:end,:);


DtrueTraining = sqdist(Xte',Xtr');
[Dball,inds] = sort(DtrueTraining,2);
Dball = mean(Dball(:,num1));
gt.kNN = DtrueTraining < Dball;

[Y_tr,Y_te,nbits] = AQH(X_tr,X_te,bit);

B1 = compactbit_var(Y_tr>0,nbits);
B2 = compactbit_var(Y_te>0,nbits);

Dhamm = hammingDist_var(B2,B1);

%%%%%%%%%%%%%%%%%%%%%%50NN-mAP
[recall, precision, ~] = recall_precision(gt.kNN, Dhamm);
mAP = VOCap(recall,precision);





function cb = compactbit_var(b,varbits)

%

% b = bits array

% cb = compacted string of bits (using words of 'word' bits)

[nSamples nbits] = size(b);

nwords = length(varbits);

cb = zeros([nSamples nwords], 'uint8');



st = 0;

for i = 1:nwords

ed = st + varbits(i);

for j = st+1:ed

cb(:,i) = bitset(cb(:,i),ed-j+1,b(:,j));

end

st = ed;

end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Dh=hammingDist_var(B1, B2)

%

% Compute hamming distance between two sets of samples (B1, B2)

%

% Dh=hammingDist(B1, B2);

%

% Input

%    B1, B2: compact bit vectors. Each datapoint is one row.

%    size(B1) = [ndatapoints1, nwords]

%    size(B2) = [ndatapoints2, nwords]

%    It is faster if ndatapoints1 < ndatapoints2

% 

% Output

%    Dh = hamming distance. 

%    size(Dh) = [ndatapoints1, ndatapoints2]

%Dh = pdist2(B1,B2,'minkowski',1);
Dh = pdist2(B1,B2);
Dh = Dh.^2;

end
