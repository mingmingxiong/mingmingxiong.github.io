function [ctrs,nbits,num_dim,var_reduc] = variantBits_AQH(da,bits)
%da: n x d
%bits: the length of hash codes
%coding: 0 is common way, 1 is gray coding

%d cells that each of cell saves the variant number of centers, for 1 bit
%save two centers, 2 for three bits, but if using gray coding, it will be
%2^i

%change kmeans to kmeans++
%assume each projection have 4 bits at most
maxbits_per_dim = 4;

    [init_vars] = init(da); 
    [out_vars, out_ctrs, out_vars_rem] = cal_vars2(da,init_vars,maxbits_per_dim);
    [M, path] = DP(out_vars,bits);

var_reduc = max(max(M));
[i,j] = size(M);
ctrs = [];
nbits = [];
num_dim = [];
while i > 0 && j > 0
    tmp = path(i,j);
    k = tmp{1}.chose;
    if k > 0
        num_dim = [num_dim i];
        nbits = [nbits k];
        ctrs = [ctrs out_ctrs(k,i)];
    end
    i = tmp{1}.i;
    j = tmp{1}.j;
    %i,j
end
end

function [init_vars] = init(da)
    init_vars = zeros(size(da,2),1);
    for i = 1:length(init_vars)
        temp = da(:,i);
        tmp = mean(temp);
        tmp1 = mean(temp);
        tmp = mean((temp-tmp).^2);
        tmp1 = mean((temp-tmp1).^2);
        init_vars(i) = max(tmp,tmp1);
    end
end



function [out_vars, out_ctrs, out_vars_rem] = cal_vars2(da,init_vars,maxbits_per_dim)
    out_vars = zeros(maxbits_per_dim+1,size(da,2));
    out_ctrs = cell(maxbits_per_dim,size(da,2));
    out_vars_rem = zeros(maxbits_per_dim,size(da,2));
    opt.MaxIter = 1000;
    for i = 1:size(da,2)
        %i
        for j = 2:maxbits_per_dim+1
%             tmp = rand(size(da,1),1);
%             tmp = tmp 
tic
            [S, ~] = softseeds(da(:,i)', 2^(j-1));
            [cids,ctrs] = kmeans(da(:,i),2^(j-1),'Start',S','options',opt);  
            toc
            tmp = 0;
            for k = 1:2^(j-1)
                ind = find(cids==k);
                temp = sum((da(ind,i)-ctrs(k)).^2);
                tmp = tmp + temp;
            end
            out_vars(j,i) = init_vars(i) - tmp/size(da,1) ;
            out_vars_rem(j-1,i) = tmp/size(da,1);
            if out_vars(j,i) < 0
                out_vars(j,i) = 0;
            end
            [ctrs,~] = sort(ctrs);
            out_ctrs(j-1,i) = {ctrs};
        end
    end
end

function [M, path] = DP(out_vars,bits)
    [d,n] = size(out_vars);
    d = d - 1;
    M = zeros(n,bits);
    path = cell(n,bits);
    for i = 1:n
        for j = 1:bits
            temp = zeros(d+1,1);
            if i == 1
                temp(1) = 0;
                for k = 1:d
                    if j >= k
                        temp(k+1) = out_vars(k+1,i);
                    else
                        temp(k+1) = 0;
                    end
                end
            else
                temp(1) = M(i-1,j);
                for k = 1:d
                    if j >= k
                        if j == k
                            temp(k+1) = out_vars(k+1,i);
                        else
                            temp(k+1) = M(i-1,j-k) + out_vars(k+1,i);
                        end
                    else
                        temp(k+1) = 0;
                    end
                end
            end
            [Y,I] = max(temp);
            M(i,j) = Y;
            tmp = struct;
            if I == 1
                tmp.i = i-1;
                tmp.j = j;
                tmp.chose = 0;
            else 
                tmp.i = i-1;
                tmp.j = j - I +1;
                tmp.chose =  I - 1;
            end
            path(i,j) = {tmp};
        end
    end
    
end