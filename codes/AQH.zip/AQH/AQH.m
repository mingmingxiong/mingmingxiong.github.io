function [Y_tr,Y_te,nbits_output] = AQH(X_tr,X_te,bit)
%XX: pre-quantization matrix m x n (m: the number of data points, n: the
%number of dimension)

%bit: the total length of binary coding

%Y: binary matrix
%nbits_output: the variable number of bits allocated for differernt dimension

manh = cell(4,1);
manh{1} = ['0' '1'];
manh{2} = ['00' '01' '10' '11'];
manh{3} = ['000' '001' '010' '011' '100' '101' '110' '111'];
manh{4} = ['0000' '0001' '0010' '0011' '0100' '0101' '0110' '0111' '1000' '1001' '1010' '1011' '1100' '1101' '1110' '1111' ];


[ctrs,nbits,num_dim, ~] = variantBits_AQH(X_tr,bit);
 

XX = [X_te;X_tr];
Y = zeros(size(XX,1),bit);
st = 1;
 for i = 1:length(num_dim)
            tt = zeros(size(XX,1),nbits(i));
            tempmanh = manh{nbits(i)};
            temp = XX(:,num_dim(i));
            tmp = ctrs{i};
            Ds = pdist2(temp,tmp);
            [~,I] = min(Ds,[],2);
            tmp1 = unique(I);
            for j = 1:length(tmp1)
                tmp2 = tempmanh(nbits(i)*(tmp1(j)-1)+1:nbits(i)*tmp1(j));
                for k = 1:nbits(i)
                    tm = tmp2(k);
                    if tm == '1'
                        tt(I==tmp1(j),k) = 1;
                    else
                        tt(I==tmp1(j),k) = 0;
                    end
                end
            end
            Y(:,st:st+nbits(i)-1) = tt;
            st = st+nbits(i);
 end
 
Y_te = Y(1:size(X_te,1),:);
Y_tr = Y(size(X_te,1)+1:end,:);
 nbits_output = zeros(size(XX,2),1);
 for i = 1:length(num_dim)
     nbits_output(num_dim(i)) = nbits(i);
 end
 
end

