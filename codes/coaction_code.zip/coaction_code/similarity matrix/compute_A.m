function C=compute_A(param,xtilde,L,lW_px,lW,weights,P)


% sqrtD*sqrtD' <=> P*1_n*1_n'*P'


% le eye(p) remplacer par diag(sqrtD) ?

%A   = eye(p) - sqrtD * sqrtD' /n - xtilde' * xtilde + lambdaAJ.*Laj;


C=P'*P-sum(P)'*sum(P)/sum(lW_px)-(xtilde*P)' * xtilde*P+10*param.optim.lapWght.*P'*L*P;
%C
%P
%xtilde
%A = (xtilde*P)'*xtilde*P
%LL = param.optim.lapWght.*P'*L*P
%save temp1.mat
%param.optim.lapWght
%C=P'*P-sum(P)'*sum(P)/sum(lW_px)-(xtilde*P)' * xtilde*P; %no temporal
%coherence
return

sum_lW_px_i=0;
sum_lW_i=0;
for i=1:param.pic.np_considered+param.pic.nd_considered

    subC=eye(lW_px(i))-ones(lW_px(i))/sum(lW_px);

    subC=subC-...
        xtilde(: , sum_lW_px_i+1:sum_lW_px_i+lW_px(i))'...
        *xtilde(: , sum_lW_px_i+1:sum_lW_px_i+lW_px(i));

    subC=subC+param.optim.lapWght.*L(sum_lW_px_i+1:sum_lW_px_i+lW_px(i),sum_lW_px_i+1:sum_lW_px_i+lW_px(i));


    %rajouter les poids :
    if i<=param.pic.np_considered
        wght_i=1./sqrt(weights(1));
    else
        wght_i=1./sqrt(weights(2));
    end
    
    subC=wght_i.*subC.*wght_i;
    
    C(sum_lW_i+1:sum_lW_i+lW(i),sum_lW_i+1:sum_lW_i+lW(i))=...
        P(sum_lW_px_i+1:sum_lW_px_i+lW_px(i),sum_lW_i+1:sum_lW_i+lW(i))'...
        *subC...
        *P(sum_lW_px_i+1:sum_lW_px_i+lW_px(i),sum_lW_i+1:sum_lW_i+lW(i));

    clear subC

    sum_lW_px_j=sum_lW_px_i+lW_px(i);
    sum_lW_j=sum_lW_i+lW(i);


    for j=i+1:param.pic.np_considered+param.pic.nd_considered
        subC=-ones(lW_px(i),lW_px(j))/sum(lW_px);

        subC=subC-...
            xtilde( :, sum_lW_px_i+1:sum_lW_px_i+lW_px(i))'...
            *xtilde( : , sum_lW_px_j+1:sum_lW_px_j+lW_px(j));

        subC=subC+param.optim.lapWght.*L(sum_lW_px_i+1:sum_lW_px_i+lW_px(i) , sum_lW_px_j+1:sum_lW_px_j+lW_px(j));

        
        
        if j<=param.pic.np_considered
            wght_j=1./sqrt(weights(1));
        else
            wght_j=1./sqrt(weights(2));
        end

        subC=wght_j*subC*wght_i;

        try
            C(sum_lW_i+1:sum_lW_i+lW(i),sum_lW_j+1:sum_lW_j+lW(j))=...
                P(sum_lW_px_i+1:sum_lW_px_i+lW_px(i),sum_lW_i+1:sum_lW_i+lW(i))'...
                *subC...
                *P(sum_lW_px_j+1:sum_lW_px_j+lW_px(j),sum_lW_j+1:sum_lW_j+lW(j));
        catch
            keyboard
        end
        clear subC

        C(sum_lW_j+1:sum_lW_j+lW(j),sum_lW_i+1:sum_lW_i+lW(i))=C(sum_lW_i+1:sum_lW_i+lW(i),sum_lW_j+1:sum_lW_j+lW(j))';

        sum_lW_px_j=sum_lW_px_j+lW_px(j);
        sum_lW_j=sum_lW_j+lW(j);

    end
    sum_lW_px_i=sum_lW_px_i+lW_px(i);
    sum_lW_i=sum_lW_i+lW(i);
end


% 
% 
% A   =diag(sqrtD.*sqrtD); 
% 
% 
% 
% 
% A = A - sqrtD * sqrtD' /n ;
% 
% A = A - xtilde' * xtilde;
% 
% A= A + lambdaAJ.*Laj;
