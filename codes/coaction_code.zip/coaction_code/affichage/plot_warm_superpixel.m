function plot_warm_superpixel(...
    param,dataBaseDir,all_position, z,z_svm,sens,nfig,lW_sp,bad_indice)
% function plot_warm_superpixel(...
%    param,dataBaseDir,all_position, z,z_svm,sens,nfig,lW_sp,bad_indice)
%
% Among other things, this is where we do the graphcut

nn1             = min(param.pic.pics,5);
pos             = 1;

color           = colormap(hot);
col_pas         = size(color,1)-1;

save_file       = 0;

param.path.save = [param.path.save,'/',num2str((sens<0)+2*(sens>0)),'/'];
sp_make_dir( param.path.save );


pos_feat_dir    = dir([dataBaseDir,'*pos']);

for i=1:param.pic.pics

    pics        = open_pics(1,param.path.im,'',i-1);
    pics        = pics{1};
    
    feature_pos = importdata([dataBaseDir,pos_feat_dir(i).name]);
    
    
    for j=1:param.objet.n_lvl_considered
        
        %% 
        
        k           = (i-1)*param.objet.n_lvl_considered+j;

        d           = dir([param.path.im,'superpixel/*_Seg.mat']);
        superpix_im = importdata([param.path.im,'superpixel/',d(i).name]);
        
        
        
        allpos      = all_position(((all_position(:,3)==i).*(all_position(:,4)==j))~=0,1:2);
        nbox        = size(allpos,1);
                
        zz          = z(pos:nbox+pos-1);
        zz_svm      = z_svm(pos:nbox+pos-1);
        
        
        zz_old      = zz;

        zz          = zz-min(zz);
        if sens==-1
            zz_old  = -zz_old;
            zz      = 1-zz./max(zz);
            zz_svm  = 1-zz_svm;
        else
           zz       = zz./max(zz);
        end



        [aa,bb]     = sort(superpix_im(:));
        aa_svm      = aa;
        aa_old      = aa;
           
        if min(allpos(:,1))>1
            aa(aa==1)                   = 0;
            aa_svm(aa_svm==1)           = 0;
            aa_old(aa_old==1)           = 0;
        end
        
        for b=1:size(allpos,1)
            aa(allpos(b,1)==aa)         = zz(b);
            aa_svm(allpos(b,1)==aa_svm) = zz_svm(b);
            aa_old(allpos(b,1)==aa_old) = zz_old(b);
        end
        
        feature_pos     = floor(feature_pos);
        feature_pos     = [feature_pos(:,2), feature_pos(:,1)];
        
        ind             = find(aa>=2);
        ind             = bb(ind);
        ind             = [floor((ind-1)/size(superpix_im,1))+1,...
                           mod(ind,size(superpix_im,1))+...
                           (mod(ind,size(superpix_im,1))==0)*size(superpix_im,1)];
                       
        X               = repmat(feature_pos(:,2),1,size(ind(:,1),1))...
                          -repmat(ind(:,1)',size(feature_pos(:,2),1),1);
                      
        Y               = repmat(feature_pos(:,1),1,size(ind(:,2),1))...
                          -repmat(ind(:,2)',size(feature_pos(:,1),1),1);
                      
        NORM_           = X.^2+Y.^2;
        
        pairs           =find(NORM_==repmat(min(NORM_),...
                         size(feature_pos(:,2),1),1));         
        pairs           = [floor((pairs-1)/size(NORM_,1))+1 ,...
                           mod(pairs,size(NORM_,1))+size(NORM_,1)...
                           *(mod(pairs,size(NORM_,1))==0)];
                       
                       
                      
        ind                         = find(aa>=2);
        [trash,ind_pairs,trash]     = unique(pairs(:,1),'first');
        pairs                       = pairs(ind_pairs,:);
        
        superpix(bb)                = aa;
        aa(ind)                     = superpix(floor(...
                                      feature_pos(pairs(:,2),2)-1)...
                                      *(size(superpix_im,1))...
                                      +floor(feature_pos(pairs(:,2),1)));
        
        superpix(bb)                = aa_svm;
        aa_svm(ind)                 = superpix(floor(...
                                      feature_pos(pairs(:,2),2)-1)...
                                      *(size(superpix_im,1))...
                                      +floor(feature_pos(pairs(:,2),1)));

        
        superpix(bb)                = aa_old;
        aa_old(ind)                 = superpix(floor(...
                                      feature_pos(pairs(:,2),2)-1)...
                                      *(size(superpix_im,1))...
                                      +floor(feature_pos(pairs(:,2),1)));
        
                                  
        aa(aa>=2)                   = 0;
        aa_svm(aa_svm>=2)           = 0;
        aa_old(aa_old>=2)           = 0;


        scores                      = zeros(size(superpix_im));
        image_svm                   = zeros(size(superpix_im));
        scores_old                  = zeros(size(superpix_im));


        scores(bb)                  = aa;
        image_svm(bb)               = aa_svm;
        scores_old(bb)              = aa_old;
        
        clear aa bb

        
        ind             = floor(scores*col_pas+1);
        tmp             = zeros([size(scores),3]);
        tmp2            = color(ind(:),:);
        tmp(:)          = tmp2(:);
        
        
        scores = scores(1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2),...
            1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2));
        
        pics = pics(1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2),...
            1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2),:);

        tmp = tmp(1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2),...
            1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2),:);

        image_svm = image_svm(1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2),...
            1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2));
        
        scores_old=scores_old(1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2),...
            1+floor(param.objet.patchSize/2):end-floor(param.objet.patchSize/2));
        
        clear tmp2 ind
        
        pos     = pos+nbox;

        if ~exist('filtre_im')
            filtre_im   = tmp/param.objet.n_lvl_considered;
        else
            filtre_im   = filtre_im+tmp/param.objet.n_lvl_considered;
        end
        clear tmp superpix_im
        
        
        TMP_graphcut    = image_svm;
        image_svm       = repmat(image_svm,[1 1 3]);
        i0              = mod(i,5)+5*(mod(i,5)==0);

        
        fig     = figure(nfig+j-2+floor((i-1)/5+1));
        if i==1
            clf
        end
        
        %% INPUT IMAGE
        
        subplot (4,nn1,i0)
        imagesc(pics)
        set(gca, 'YTick', [])
        set(gca, 'XTick', [])
        
        %% RESULT OF OUR ALGORITHM
        
        subplot (4,nn1,nn1+i0)
        imagesc(filtre_im);
        colormap(hot)
        set(gca, 'YTick', [])
        set(gca, 'XTick', [])

        %% SEGMENTATION WITH A SIMPLE ROUNDING using zz=(z>0)
            
        subplot (4,nn1,2*nn1+i0)
        image_svm=image_svm.*pics+(image_svm==0);
        imagesc(image_svm);
        set(gca, 'YTick', [])
        set(gca, 'XTick', [])
        hold on
       
        
        subplot (4,nn1,i0+3*nn1)
        
        %% GRAPHCUT -- can be replace by any method
        
        picsBW=ow_rgb2gray(pics);
        DataCost = repmat(TMP_graphcut,[1 1 2]);
        DataCost(:,:,2)=1-DataCost(:,:,1);
        SmoothnessCost=30*[0 1;1 0];
        vC = [exp(-500*abs(picsBW(2:end,:)-picsBW(1:(end-1),:)).*abs(picsBW(2:end,:)-picsBW(1:(end-1),:))) ; zeros(1,size(picsBW,2))];
        hC = [exp(-500*abs(picsBW(:,2:end)-picsBW(:,1:(end-1))).*abs(picsBW(:,2:end)-picsBW(:,1:(end-1)))) , zeros(size(picsBW,1),1)];
        [gch] = GraphCut('open', DataCost, SmoothnessCost, vC, hC);
        [gch L] = GraphCut('expand',gch);
        [gch] = GraphCut('close', gch);
        picsBW=double(pics).*double(repmat(L,[1 1 3]))+double(repmat(L==0,[1 1 3]));
        imagesc(picsBW);
        set(gca, 'YTick', [])
        set(gca, 'XTick', [])
        hold on
 
        
        if save_file==1

            fig=figure(1);clf
            imagesc(filtre_im);
            colormap(hot)

            set(gca, 'YTick', [])
            set(gca, 'XTick', [])

            set(fig, 'Position',[1, 1, size(pics,1), size(pics,2)], 'PaperPositionMode', 'auto');
            print('-depsc', [param.path.save,param.path.save_file,'_',num2str(param.pic.list(i)),'superpix1_colormap.eps']);
            fig=figure(1);clf
            imagesc(image_svm);
            set(gca, 'YTick', [])
            set(gca, 'XTick', [])
            set(fig, 'Position',[1, 1, size(pics,1), size(pics,2)], 'PaperPositionMode', 'auto');
            print('-depsc', [param.path.save,param.path.save_file,'_',num2str(param.pic.list(i)),'superpix1_hardthresh.eps']);
            
            fig=figure(1);clf
            imagesc(picsBW);
            set(gca, 'YTick', [])
            set(gca, 'XTick', [])
            set(fig, 'Position',[1, 1, size(pics,1), size(pics,2)], 'PaperPositionMode', 'auto');
            print('-depsc', [param.path.save,param.path.save_file,'_',num2str(param.pic.list(i)),'superpix1_graphCut.eps']);
            
            fig=figure(1);clf
            imagesc(pics);
            set(gca, 'YTick', [])
            set(gca, 'XTick', [])
            set(fig, 'Position',[1, 1, size(pics,1), size(pics,2)], 'PaperPositionMode', 'auto');
            
            
            pic_output_path=[param.path.im,'eps_dir_wo_edge/'];
            sp_make_dir(pic_output_path);
            print('-depsc', [pic_output_path,sprintf('%02i',param.pic.list(i)),'.eps']);


        end
        clear filtre_im
        clear image_svm
 
    end   
    clear pics
end