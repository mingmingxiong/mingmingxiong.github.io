function movingcue(folder,out_folder,isgray)

files = dir([folder '/*.flo']);
files_img = dir([folder '/*.png']);
F = 8;
if length(files) == 0
    return;
end
str = [folder '/' files(1).name];
img = readFlowFile(str);
flowsx = zeros(size(img,1),size(img,2),F);
flowsy = zeros(size(img,1),size(img,2),F);
M = zeros(size(img,1),size(img,2),2*F);

h = size(img,1);
w = size(img,2);
y = 10:5:h-10;
x = 10:5:w-10;
yy = repmat(y',length(x),1);
xx = repmat(x,length(y),1);
xx = xx(:);
P = length(yy);
% %%
% addpath(genpath('code'));
% modelpath = 'Model/';
% 
%  detectorlist = detectorset(); L = length(detectorlist);
%  nlevel = 3; dim = 44604; interval=10; nmap = 12; Level=(interval+1):5:(interval+20);
%  load([modelpath, num2str(detectorlist{1}), '_final.mat']);
% %%
start = 1;
for i = start:length(files)-F
    if i == 1
        for j = 2:F+start
            img = readFlowFile([folder '/' files(i+j-1).name]);
            flowsx(:,:,j) = img(:,:,1);
            flowsy(:,:,j) = img(:,:,2);
            %             M(:,:,(j-1)*2+1:j*2) = img;
        end
    else
        img = readFlowFile([folder '/' files(i+F).name]);
        flowsx(:,:,F+1) = img(:,:,1);
        flowsy(:,:,F+1) = img(:,:,2);
        %         M(:,:,F*2+1:(F+1)*2) = img;
        flowsx = flowsx(:,:,2:end);
        flowsy = flowsy(:,:,2:end);
        %         M = M(:,:,3:end);
    end
    
    imgname = [folder '/' files_img(i).name];
% %     %%
%      im = imread(imgname); im_r = resize_img(im, 400);
%  	[feat_py, scales] = featpyramid(im_r, 8, 10);
%      [bbox responsemap] = detect_with_responsemap(Level, feat_py, scales, im, model, model.thresh);
%      h_p = responsemap{2};
%      h_p = imresize(h_p,[size(im,1) size(im,2)]);
%      h_p = (h_p-min(h_p(:)))/(max(h_p(:))-min(h_p(:)));
%     %%
    img_rgb = im2double(imread(imgname));
    r = img_rgb(y,x,1); r = r(:);
    g = img_rgb(y,x,2); g = g(:);
    b = img_rgb(y,x,3); b = b(:);
    if isgray == 1
        feas = [r xx yy];
    else
        feas = [r g b xx yy];
    end
    feas = double(feas);
    tempM1 =[yy'; xx'];
    M = [];%zeros(2,P);
    
    for j = 1:F
        tempM = [];
        %tempM1 = M((j-1)*2+1:(j)*2,:);
        tempflowx = flowsx(:,:,j);
        tempflowy = flowsy(:,:,j);
        for jj = 1:size(feas,1)
            tempx = tempM1(2,jj);
            tempy = tempM1(1,jj);
            tempx = min(tempx,size(img,2));
            tempx = max(tempx,1);
            tempy = min(tempy,size(img,1));
            tempy = max(tempy,1);
            
            tx = tempflowx(tempy,tempx);
            ty = tempflowy(tempy,tempx);
            tempM1(2,jj) = round(tempx+tx);
            tempM1(1,jj) = round(tempy+ty);
            tempM = [tempM [ty;tx]];
        end
        M = [M;tempM];
    end
    
    [labels,res] = SparseLabeling(M,F,P,1.2,floor(4*P/5));
    %H = eye(5);
    %     H = cov(feas);
    H1 = cov(feas(:,1:end-2));
    H2 = cov(feas(:,end-1:end))/4;
    H = eye(size(feas,2));
    H(1:end-2,1:end-2)=H1;
    H(end-1:end,end-1:end)=H2;
    [fg,bg] = pixellabel(labels,feas,feas,H);
    fb = fg+bg;
    fg = fg./fb;
    bg = bg./fb;
    %fg = fg*0.75+0.25*(1-res)';
    
    img_moving = zeros(size(img_rgb,1),size(img_rgb,2));
    img_label = zeros(size(img_rgb,1),size(img_rgb,2));
    for j = 1:size(feas,1)
        img_label(feas(j,end)-2:feas(j,end)+2,feas(j,end-1)-2:feas(j,end-1)+2) = labels(j);
        img_moving(feas(j,end)-2:feas(j,end)+2,feas(j,end-1)-2:feas(j,end-1)+2) = fg(j);
    end
    
    str1=[folder '/' files_img(i).name '.jpg']
    imwrite(img_label,[out_folder '/' files_img(i).name '.jpg']);
    %img_moving = img_moving + 0.1*h_p;
    %img_moving = img_moving + 0.1*h_p;
    imwrite(img_moving,[out_folder '/' files_img(i).name '_m_p.png']);
    %imwrite(h_p,[out_folder '/' files_img(i).name '_h_p.png']);
end
