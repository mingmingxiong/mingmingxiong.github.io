clear all

param.objet.type = 'knut';
param.pic.pics   = 2;

patchSize        = 16;
gridSpacing      = 4;
n_lvl            = 1;

maxImageSize    = 1000;
featureSuffix   = '_sift.mat'; 

path_parameters;

param.path.obj  = [param.path.im,'descriptor/sift/'];


d               = dir([param.path.im,'*',param.objet.type,'*']);
d_size          = size(d,1);


np_considered   = min(param.pic.pics,d_size);
imageFileList   = cell(np_considered,1);
i0              = 1;
i               = 1;

while i0<=np_considered && i<=size(d,1)
    if ~strcmp(d(i).name(1),'.') && ~d(i).isdir
        imageFileList{i0}   = d(i).name;
        i0                  = i0+1;
    end  
    i                       = i+1;
end


GenerateSiftDescriptors( imageFileList, param.path.im, param.path.obj, maxImageSize, gridSpacing,patchSize, 0 );
clear param.path.feat_tmp


