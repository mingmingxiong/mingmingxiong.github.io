function omega = rad2deg(theta)
% Transform degrees to radians.

omega = theta * 180 / pi;