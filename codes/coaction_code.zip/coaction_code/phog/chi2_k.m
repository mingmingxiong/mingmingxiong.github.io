function K = chi2_k(X1,X2)
%function k = chi2_k(x,y)
%x: d x n
%y: d x n

%%
%temp1 =(x-y).^2;
n1 = size(X1,2);
n2 = size(X2,2);
% temp = X1+X2;
% XX1 = sum(X1 .* X1); XX2 = sum(X2 .* X2); X12 = X1' * X2; 
% DSq = repmat(XX1', [1 n2]) + repmat(XX2, [n1 1]) - 2 * X12;
K = zeros(n1,n2);
for i = 1:n1
    temp = X1(:,i);
    temp = repmat(temp,1,n2);
    temp1 = (X2-temp).^2;
    temp2 = (X2+temp)*2 + 1e-5;
    temp = temp1./temp2;
    K(i,:) = sum(temp,1);
    ind = find(K(i,:)>1);
    if length(ind) > 0
       X1(:,i);
       X2(:,ind(1));
       save temp.mat
       return;
    end
    
end
%%
%temp2 = (x+y)/2 + 1e-5;

K = 1- K;
%K = K -eye(size(K,1));

