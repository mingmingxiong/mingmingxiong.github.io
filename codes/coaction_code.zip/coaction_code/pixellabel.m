function [fg,bg] = pixellabel(labels,feas,pixs,H)
%labels: P x 1 binary vector
%feas: P x 5 [ r,g,b,x,y ] % for the same frame
%pixs: n x 5
%H: bandwidth matrix
% you can use the weighted kNN neighbor to estimate the H automatically, and
% the weight is obtained by cross validation
feas = double(feas);
pixs = double(pixs);

fea_f = feas(labels==0,:);
fea_b = feas(labels==1,:);

num_f = size(fea_f,1);
num_b = size(fea_b,1);

num = size(pixs,1);

fg = [];
bg = [];
H_half = H^(-0.5);
H_det = det(H)^(-0.5);
% for i = 1:size(pixs,1)
%     temp = pixs(i,:);
%     temp = repmat(temp,num_f,1);
%     temp = temp +(-1)*fea_f;
%     temp = H_half * temp';
%     temp = -sum(temp.^2,1);
%     temp = sum(exp(temp))*H_det/num_f;
%     fg = [fg;temp'];
%     
%     temp = pixs(i,:);
%     temp = repmat(temp,num_b,1);
%     temp = temp - fea_b;
%     temp = H_half * temp';
%     temp = -sum(temp.^2,1);
%     temp = sum(exp(temp))*H_det/num_b;
%     bg = [bg;temp'];
% end
tempp = H_half*pixs';
temp_fea = H_half*fea_f';
s = zeros(1,size(pixs,1));
tic
for i = 1:size(temp_fea,2)
    temp = repmat(temp_fea(:,i),1,size(pixs,1));
    temp = -sum((temp-tempp).^2,1);
    temp = exp(temp);
    s = s + temp;
end
toc
temp = s*H_det/num_f;
fg = [fg;temp'];

temp_fea = H_half*fea_b';
s = zeros(1,size(pixs,1));
for i = 1:size(temp_fea,2)
    temp = repmat(temp_fea(:,i),1,size(pixs,1));
    temp = -sum((temp-tempp).^2,1);
    temp = exp(temp);
    s = s + temp;
end
temp = s*H_det/num_f;
bg = [bg;temp'];