function L=graphCuting_pr(pic,score,wdth,lgth,lambda,sens)

%pic=rgb2gray(pic);
pic_01=reshape(score,wdth,lgth);


pic_01=(sens*pic_01)<(sens*lambda);

DataCost = repmat(pic_01,[1 1 2]);
DataCost(:,:,2)=(DataCost(:,:,1)==0);

SmoothnessCost=50*[0 1;1 0];

vC = [exp(-60*abs(pic(2:end,:)-pic(1:(end-1),:))) ; zeros(1,size(pic,2))];
hC = [exp(-60*abs(pic(:,2:end)-pic(:,1:(end-1)))) , zeros(size(pic,1),1)];

[gch] = GraphCut('open', DataCost, SmoothnessCost, vC, hC);

[gch L] = GraphCut('expand',gch);
[gch] = GraphCut('close', gch);


