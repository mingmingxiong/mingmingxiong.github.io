function [H,lW,tab_lambda0,weights]=main_kernel1(param)
% function [xtilde,lW,tab_lambda0,weights]=main_kernel(param)
%
% extract features and compute kernel matrix 

[all_descriptor, trash ,lW,tab_lambda0,trash]=open_pixelwise(param);
clear trash

weights=[sum(lW(1:param.pic.np_considered));sum(lW(param.pic.np_considered+1:end))];

all_descriptor=all_descriptor';

fprintf(' =>evaluating kernel:\n')

%[ xtilde , trash,trash ] = compute_kernel(all_descriptor,param.kernel,0,weights,param);

str = sprintf('%sH.mat',param.path.im);
H = double(importdata(str));
lambda = 1e-2;%1e-1;
temp = ones(size(H,1))*ones(size(H,1))';
C = temp*H*temp +  size(H,1)*lambda * eye(size(H,1));
H = inv(C)';

fprintf('  done')
clear all_descriptor trash