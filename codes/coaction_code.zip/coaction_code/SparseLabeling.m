function [outlabels,res] = SparseLabeling(M,F,P,threshold,d)
% RANSAC algorithm
% M: 2F x P, P points across F frames
% threshold: FOr finding inlier trajectories
% d: stop critrior
% threshold: 0.01,

T = 100;
errs = [];
for i = 1:20
    t = 0;
    num = 3;
    maxd =0;
    outlabels = [];
    while t < T
        order = randperm(P);
        tempw = M(:,order(1:num));
        %P_m = tempw*inv(tempw'*tempw)*tempw'; %may be pinv
        P_m = tempw/(tempw'*tempw)*tempw'; %may be pinv
        f = sum((P_m*M -M).^2,1).^(0.5);
        labels = double(f<threshold);
        if sum(labels)>maxd
            maxd = sum(labels);
            outlabels = labels;
            errs = f;
        end
        if sum(labels) > d
            break;
        end
        t = t + 1;
    end
    if maxd > d
        break;
    else
        threshold = threshold + 1;
        continue;
    end
end

errs = (errs-max(errs))/2;
res = 1-exp(errs);
maxd
t