function extractfeature(folder,outfile,flag)

vis = dir([folder '/*.mat']);
num = 4000;
vis_feas = [];
index = 1;
for i=1:length(vis)
    load([folder '/' vis(i).name]);
    da = v1;
    vis(i).name
    if size(da,1) < 10
        continue;
    end
    
    da = round(da);
    frames = unique(da(:,3));
    vi = [];
    num_max = max(frames);
    for j = 1:length(frames)
        if frames(j) > num_max -10
            continue;
        end
        temp = da(da(:,3)==frames(j),:);
        stemp = sprintf('%05d',frames(j));
        str = ['data1/' vis(i).name(1:end-4) '_out' '/' stemp '.png.jpg'];%_m_p.png'];
        weight = im2double(imread(str));
        weight(weight>0.0001) = 1;
        %%%without weight
        if flag == 1
        weight = ones(size(weight));
        end
        
        
        
        output = weightedBoW1(temp, weight, num);
        vi = [vi [frames(j);output] ];
    end
    vis_feas(index).vi = vi;
    vis_feas(index).name = vis(i).name;
    index = index + 1;
end

save(outfile, '-v7.3', 'vis_feas');
