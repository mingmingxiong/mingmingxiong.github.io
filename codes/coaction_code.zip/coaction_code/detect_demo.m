% detect_demo.m is a small demo to show the detection result in specific image
% name is the path of image
% Ran Xu
% e.g:
% detect_demo('/Users/rxu2/Desktop/mindseye/gtruth/APPROACH8_A1_C1_Act2_PAR
% K1_ML_MIDD_DARK_90336fd9-e83c-11df-be21-e80688cb869a/0421.bmp')
 function detect_demo(name)
 load('INRIA/inriaperson_final');
 load('all_data.mat');

cls = model.class;
% load and display image
im = imread(name);
clf;
image(im);
axis equal; 
axis on;

[dets, boxes] = imgdetect(im, model, -0.3);
top = nms(dets, 0.5);
clf;
showboxes(im, reduceboxes(model, boxes(top,:)))
%saveas(gcf,strcat('box_jump70',num2str(i),num2str(j),'.fig'));
disp('Felzenschwalb detections');

% get bounding boxes
bbox = bboxpred_get(model.bboxpred, dets, reduceboxes(model, boxes));
bbox = clipboxes(im, bbox);
top = nms(bbox, 0.5);
clf;
sprintf('the left top and right bottom coordinate of the bounding box is: (%d,%d) and (%d,%d)',bbox(top,1),bbox(top,2),bbox(top,3),bbox(top,4))
showboxes(im, bbox(top,:));


