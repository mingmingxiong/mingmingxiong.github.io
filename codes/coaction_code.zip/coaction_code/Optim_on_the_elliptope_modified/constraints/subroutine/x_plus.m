function [X]=x_plus(X,epsilon)

X=X.*(X>epsilon);