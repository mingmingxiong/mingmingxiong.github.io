function sum_x=sum_x_over_V(x,V)

sum_x=sum(x_over_V(x,V));