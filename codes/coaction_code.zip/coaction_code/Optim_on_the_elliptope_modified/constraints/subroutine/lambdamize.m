function V=lambdamize(norm,lambda,X)

% lambdamize X and put it in V
V=lambda.*X./norm;