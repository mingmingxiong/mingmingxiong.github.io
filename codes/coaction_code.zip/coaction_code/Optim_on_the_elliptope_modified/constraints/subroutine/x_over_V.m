function xx=x_over_V(x,V)

id_im=V*ones(1,size(x,2));
xx=x.*id_im;