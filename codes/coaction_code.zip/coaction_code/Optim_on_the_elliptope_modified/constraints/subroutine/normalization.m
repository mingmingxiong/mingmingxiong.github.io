function nor=normalization(npics,n)

nor=npics*n;