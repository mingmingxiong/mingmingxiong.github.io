function output = weightedBoW(index_img, weight, num)

%for two level

[h,w]= size(index_img);
output = zeros(num,5);
for i = 1:num
    temp = index_img == i;
    temp = weight.*temp;
    output(i,1) = sum(temp(:));
    output(i,2) = sum(sum(temp(1:h/2,1:w/2)));
    output(i,3) = sum(sum(temp(1:h/2,w/2:w)));
    output(i,4) = sum(sum(temp(h/2:h,1:w/2)));
    output(i,5) = sum(sum(temp(h/2:h,w/2:w)));
end

output(:,1) = output(:,1)./(sum(output(:,1))+1e-20);
output(:,2) = output(:,2)./(sum(output(:,2))+1e-20);
output(:,3) = output(:,3)./(sum(output(:,3))+1e-20);
output(:,4) = output(:,4)./(sum(output(:,4))+1e-20);
output(:,5) = output(:,5)./(sum(output(:,5))+1e-20);

output = output(:);