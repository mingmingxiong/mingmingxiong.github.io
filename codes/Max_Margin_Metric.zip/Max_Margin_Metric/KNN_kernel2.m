function preds = KNN_kernel(y, X, alpha1,fa_hat,B,sigma, k, Xt)
% function preds = KNN(y, X, M, k, Xt)
% perform knn classification on each row of Xt
% M is the factor matrix : A = M*M'


add1 = 0;
if (min(y) == 0),
    y = y + 1;
    add1 = 1;
end
[n,m] = size(X);
[nt, m] = size(Xt);
% K = (X*M)*(M'*Xt');
% l = zeros(n,1);
% for (i=1:n),
%     l(i) = (X(i,:)*M)*(M'*X(i,:)');
% end
% 
% lt = zeros(nt,1);
% for (i=1:nt),
%     lt(i) = (Xt(i,:)*M)*(M'*Xt(i,:)');
% end

% n = size(X1,1);
% nt = n;
% D1 = zeros(n, nt);
% for (i=1:n),
%     for (j=1:nt),
% %         D(i,j) = l(i) + lt(j) - 2 * K(i, j);
%           D1(i,j) = getMetric(X1(i,:),X2(j,:),fa_hat*alpha1,B,sigma);%time consuming
%     end
% end

D = zeros(n, nt);
for (i=1:n),
    for (j=1:nt),
%         D(i,j) = l(i) + lt(j) - 2 * K(i, j);
          D(i,j) = getMetric2(X(i,:),Xt(j,:),fa_hat,B,sigma);%time consuming
    end
end

[V, Inds] = sort(D);

preds = zeros(nt,1);
for (i=1:nt),
    counts = [];
    for (j=1:k),        
        if (y(Inds(j,i)) > length(counts)),
            counts(y(Inds(j,i))) = 1;
        else
            counts(y(Inds(j,i))) = counts(y(Inds(j,i))) + 1;
        end
    end
    [v, preds(i)] = max(counts);
end
if (add1 == 1),
    preds = preds - 1;
end