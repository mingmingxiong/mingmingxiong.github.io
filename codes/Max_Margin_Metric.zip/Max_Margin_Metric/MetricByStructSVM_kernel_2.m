function [alpha1,fa_hat,B,sigma] = MetricByStructSVM_kernel_2(X,Cs,C_svm,epsilon,k_max,sigma,gamma)%(X,C,2000,0.001,50,1,1e-8)
% there are many place waste time and space
%for linear subspace pursuit
%OK 1
H = [];
fa = [];
beta = [];
fa_hat = [];%nxl, n: the number of basis, coefficients matrix
beta_hat = []; %lx1 vector
alpha1 = [];
l = 0;
delta = 0;
B = [];  %pxn, p=1+2*d
G = [];
Lg = [];
K = [];

fa_data = [];
X1 = X(Cs(:,1),:);
X2 = X(Cs(:,2),:);
for i = 1:size(X1,1)
    fa_data = [fa_data; [Cs(i,3) X1(i,:) X2(i,:)]];
end
d = size(X,2);
H = [];
X_c = [];
X_b = [];
f = [];
f1 = [];
Xi = 1;
b_r = 1;
G =[];
while(1)
    if(size(fa_hat,1)>0)
        A = ones(1,length(H));
        b = [C_svm];
        lb = zeros(length(H),1);
        ub = ones(length(H),1).*inf;
        % no starting point
        x0 = [];
        Aeq = [];
        beq = [];
        % we need to tell the optimizer to use the medium scale version for this
        % problem formulation
        options = optimset('LargeScale','on');

        [alpha1,fval] = quadprog(H,f1,A,b,Aeq,beq,lb,ub,x0,options);
        %fval
        tol = 1e-8;
        b_r = beta_hat* alpha1/10;
        ind_x = find(alpha1>tol);
        alpha1(find(alpha1<=tol)) = 0;
        Xi = (-f1'*alpha1 - alpha1'*H*alpha1)/C_svm;
    end

    l = l + 1;
    c = zeros(size(X1,1),1);
    c1 = zeros(size(X1,1),1);
    %fa_temp = [];
    beta_temp = 0;
    for i = 1:size(X1,1)
        c(i) = Cs(i,3)*recog(X1(i,:),X2(i,:),fa_hat,B,alpha1,b_r,sigma);%(-X3(i,:)*M_r*X3(i,:)'+b_r);
        if c(i) <= 1
            c1(i) = 1;
            beta_temp = beta_temp + Cs(i,3);
            %fa_temp = [fa_temp; [Cs(i,3) X1(i,:) X2(i,:)]];
        end
    end

    %     if  abs(beta_temp) < 5
    %         break;
    %     end
    fa{l}.b = beta_temp;
    fa{l}.c = c1;
    fa{l}.y = Cs(:,3);

    Xi+epsilon
    sum(c1)/size(X1,1)-c1'*c/size(X1,1)
    %         sum((c>0).*(Cs(:,3)<0))
    %         sum((c>0).*(Cs(:,3)>0))
    %         sum(c>0)
    %         sum(c>1)

    %         size(B,2)
    if size(fa_hat,1)>0 && sum(c1)/size(X1,1)-c1'*c/size(X1,1) <= Xi+epsilon
        sum((c>0).*(Cs(:,3)<0))
        sum((c>0).*(Cs(:,3)>0))
        sum(c>0)
        sum(c>1)
        break;
    end
    if size(B,2) >= k_max
        break;
    end
    if l > 2*k_max
        break;
    end

    f1 = [f1;-sum(c1)/size(X1,1)];
    [bchange,B,G,Lg,K] = basis_extend(B,fa{l},sigma,gamma,fa_data,K,Lg,G);
    while size(B,2) < 1
        [bchange,B,G,Lg,K] = basis_extend(B,fa{l},sigma,gamma,fa_data,K,Lg,G);
    end
    if bchange == 1;
        fa_hat = zeros(size(B,2),l);
        beta_hat = zeros(1,l);
        for i = 1:l
            [fa_hat(:,i),err] = projection(fa{i},B,Lg,fa_data,K);
        end
        beta_hat = sum(fa_hat,1);
    else
        [temp,err] = projection(fa{l},B,Lg,fa_data,K);
        fa_hat = [fa_hat temp];
        beta_hat = sum(fa_hat,1);
    end
    f = (-abs(beta_hat))';

    H = calH(fa_hat,B,sigma);
end
%make positive
fa_hat = fa_hat*alpha1;  % d(B) by 1, d(B):number of basis
fa_hat(find(fa_hat>0)) = 0; % becasue w = fa_hat*(-x*x')
end

function H = calH(fa_hat,B,sigma)
nb = size(B,1);
d = floor(nb/2);
Hb = zeros(size(B,2));
for i = 1:size(B,2)
    for j = i:size(B,2)
        x1 = B(2:(1+d),i);
        x2 = B((2+d):end,i);
        x3 = B(2:(1+d),j);
        x4 = B((2+d):end,j);
        Hb(i,j) = 0.01+(rbf(x1,x3,sigma) + rbf(x2,x4,sigma) - ...
            rbf(x2,x3,sigma) - rbf(x1,x4,sigma))^2;
        Hb(j,i) = Hb(i,j);
    end
end
H = fa_hat' * Hb * fa_hat;
end

function v = rbf(x1,x2,sigma)
%v = exp(-sum((x1-x2).^2)*sigma);
v = sum(x1.*x2);
%  v = (sigma*sum(x1.*x1)*sum(x2.*x2));
end

function v = recog(x1,x2,fa_hat,B,al,b,sigma)%(X1(i,:),X2(i,:),fa_hat,B,alpha1,b_r)%(-X3(i,:)*M_r*X3(i,:)'+b_r);
coff = fa_hat * al;
nb = size(B,1);
d = floor(nb/2);
v = 0;
for i = 1:size(B,2)
    x3 = B(2:(1+d),i)';
    x4 = B((2+d):end,i)';
    temp = 0.01+(rbf(x1,x3,sigma) + rbf(x2,x4,sigma) - ...
        rbf(x2,x3,sigma) - rbf(x1,x4,sigma))^2;
    v = v + coff(i) * temp;
end

if size(B,2) == 0
    v = v + b;
end

end

function [bchange,B,G,Lg,K] = basis_extend(B, fa,sigma,gamma,fa_data,K,Lg,G)
[cof,err] = projection(fa,B,Lg,fa_data,K);
bchange = 0;
if err < gamma
    B = B;
    bchange = 0;
    return;
else

    Tmax = 50;
    nb = size(fa_data,2);
    d = floor(nb/2);
    beta = 1;
    while(1)
        ra = randperm(size(fa_data,1));
        temps=fa_data(ra(1),:);
        x1 = temps(2:(d+1))';
        x2 = temps((d+2):end)';
        if sum(abs(x1-x2))>0.01
            break;
        end
    end
    x1temp = x1;
    x2temp = x2;
    %     for i = 1:Tmax
    %         [beta1, x1temp, x2temp] = grad3(beta,x1temp,x2temp,fa_data,fa,B,cof,sigma,i);
    %         if abs(beta1-beta) < 1e-5
    %             break;
    %         end
    %         abs(beta1-beta);
    %         beta = beta1;
    % %         beta = beta - d_beta;
    % %         x1 = x1 - d_x1;
    % %         x2 = x2 - d_x2;
    %     end
    %     beta
    X_c_temp = zeros(d,d);
    for i = 1:(size(fa_data,1))
        if fa.c(i) == 1
            X_c_temp = X_c_temp + fa.y(i)*(-(fa_data(i,2:(d+1))-fa_data(i,(d+2):end))'*(fa_data(i,2:(d+1))-fa_data(i,(d+2):end)));
        end
    end
    X_c_temp = X_c_temp/size(fa_data,1);
    for i = 1:(size(B,2))

        X_c_temp = X_c_temp - cof(i)*(-(B(2:(d+1),i)-B((d+2):end,i))*(B(2:(d+1),i)-B((d+2):end,i))');

    end

    [v,d] = eigs(X_c_temp);
    d = diag(abs(d));
    %    [va,id] = max(d);
    %    x2temp = x1temp +(v(:,id)*(va^(0.5)));%[0.8507;-0.3045;2.3275;1.0145];
    %     x1 = x1temp;
    %     x2 = x2temp;
    flag = 0;
    Bs =  find( abs(d) > 1e-3 );
    for i = 1:length(Bs)
        x2temp = x1temp+v(:,Bs(i))*d(Bs(i));
        B = [B [0.1;x1temp;x2temp]];
        flag = 1;
    end
end
if flag == 1;
    bchange = 1;
    nb = size(B,1);
    d = floor(nb/2);
    G = zeros(size(B,2));
    for i = 1:size(B,2)
        for j = i:size(B,2)
            x1 = B(2:(1+d),i);
            x2 = B((2+d):end,i);
            x3 = B(2:(1+d),j);
            x4 = B((2+d):end,j);
            G(i,j) = 0.01+(rbf(x1,x3,sigma) + rbf(x2,x4,sigma) - ...
                rbf(x2,x3,sigma) - rbf(x1,x4,sigma))^2;
            G(j,i) = G(i,j);
        end
        for j = 1:size(fa_data,1)
            x1 = B(2:(1+d),i);
            x2 = B((2+d):end,i);
            x1 = x1';
            x2 = x2';
            x3 = fa_data(j,2:(1+d));
            x4 = fa_data(j,(2+d):end);
            K(i,j) = 0.01+(rbf(x1,x3,sigma) + rbf(x2,x4,sigma) - ...
                rbf(x2,x3,sigma) - rbf(x1,x4,sigma))^2;
        end
    end
    if sum(sum(isnan(G)))>0
        dead = 1;
    end
    Lg = chol(G+1e-10*eye(size(G,1)),'lower');
end
end



function [beta, x1, x2] = grad3(beta,x1,x2,fa_data,fa,B,cof,sigma,t)
alp = fa.c .* fa.y/length(fa.c);
d = floor(size(fa_data,2)/2);
v1 = zeros(size(fa_data,1)+size(B,2),4);
f1 = fa_data(:,2:(d+1));
f2 = fa_data(:,(d+2):end);

if length(cof) > 0
    bet = -cof;
    alp = [alp;bet];
    B = B';
    f1 = [f1;B(:,2:(d+1))];
    f2 = [f2;B(:,(d+2):end)];
end
%     v1(:,1) = rbf2(x1',f1,sigma);
%     v1(:,2) = rbf2(x2',f2,sigma);
%     v1(:,3) = -rbf2(x1',f2,sigma);
%     v1(:,4) = -rbf2(x2',f1,sigma);
%     v_t = repmat((sum(v1,2)),1,4);%%qi
% %     v_tt = v_t.*v1;
%     qi = v_t(:,1);
x = x1-x2;
x = (f1'-f2') * (2*alp.*(x'*(f1'-f2'))')/(alp'*((f1'-f2')'*x).^2);
x2 = x1-x;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      p12 = 0.01 + (rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma))^2;
%      %temp1 = 1;%%think about this:
% %      temp1 = (0.01/(rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma)) + (rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma)));
%      temp1 = ((rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma)));
%      %temp1 = 1;
%      ra11 = 2*temp1*(alp.*((qi+0.01).*v1(:,1)));
%      ra12 = 2*temp1*(alp.*((qi+0.01).*v1(:,3)));
%      f11 = f1-repmat(x1',size(f1,1),1);
%      f12 = f2-repmat(x1',size(f2,1),1);
%      ra13_1 = (2*rbf(x1,x2,sigma))*(alp'*(0.01+qi.^2));
%      denom1 =  ra13_1;
%      x12 = (f11'*ra11+f12'*ra12)/denom1;
%      x1 = x12+x2;
%
% %      ra11 = 2*temp1*(alp.*((qi).*v1(:,1)));
% %      ra12 = 2*temp1*(alp.*((qi).*v1(:,3)));
% %      f11 = f1-repmat(x1',size(f1,1),1);
% %      f12 = f2-repmat(x1',size(f2,1),1);
% %      ra13_1 = (2*rbf(x1,x2,sigma))*(alp'*(qi.^2));
% %      denom1 =  ra13_1;
% %      x12 = (f11'*ra11+f12'*ra12)/denom1;
% %      x1 = x12+x2;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
% %     v1(:,1) = rbf2(x1',f1,sigma);
% %     v1(:,2) = rbf2(x2',f2,sigma);
% %     v1(:,3) = -rbf2(x1',f2,sigma);
% %     v1(:,4) = -rbf2(x2',f1,sigma);
% %     v_t = repmat((sum(v1,2)),1,4);%%qi
% % %     v_tt = v_t.*v1;
% %     qi = v_t(:,1);
% % %     x = x1-x2;
% % %      x = (f1'-f2') * (2*alp.*(x'*(f1'-f2'))')/(alp'*((f1'-f2')'*x).^2);
% % %     x2 = x1-x;
% %
% %      p12 = 0.01 + (rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma))^2;
% %      %temp1 = 1;%%think about this:
% %      temp1 = (0.01/(rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma)) + (rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma)));
% %      ra21 = 2*temp1*(alp.*((qi+0.01).*v1(:,2)));
% %      ra22 = 2*temp1*(alp.*((qi+0.01).*v1(:,4)));
% %      f21 = f2-repmat(x2',size(f1,1),1);
% %      f22 = f1-repmat(x2',size(f2,1),1);
% %      ra13_2 = (2*rbf(x1,x2,sigma))*(alp'*(0.01+qi.^2));
% %      denom2 =  ra13_2;
% %      x21 = (f21'*ra21+f22'*ra22)/denom2;
% %      x2 = x21+x1;
%
%     if sum(abs(x1)>20) || sum(abs(x2)>20)
%         dead = 1;
%     end


v1(:,1) = rbf2(x1',f1,sigma);
v1(:,2) = rbf2(x2',f2,sigma);
v1(:,3) = -rbf2(x1',f2,sigma);
v1(:,4) = -rbf2(x2',f1,sigma);
beta = (alp'*((sum(v1,2)).^2 + 0.01))/(0.01+(rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma))^2);
end



function v = rbf2(x1,x2,sigma)
x1 = repmat(x1,size(x2,1),1);
%v = exp(-sum((x1-x2).^2,2)*sigma);
v = sum(x1.*x2,2);
%  v = (sigma*sum(x1.*x1,2).*sum(x2.*x2,2));
end

function [cof,err] = projection(fa,B,Lg,fa_data,K)
if size(B,2) == 0
    cof = [];
    err = inf;
else
    c = fa.c;
    Y_l = (c/size(c,1)).*fa.y;
    opts.LT = true;
    opts.UT = false;
    cof_hat = linsolve(Lg,K*Y_l,opts);
    opts.LT = false;
    opts.UT = true;
    cof = linsolve(Lg',cof_hat,opts);
    err = inf; %% we need an efficient way to calculate the residual error, but I can't now.
end
end

function [beta, x1, x2] = grad1(beta,x1,x2,fa_data,fa,B,cof,sigma,t)
alp = fa.c .* fa.y/length(fa.c);
d = floor(size(fa_data,2)/2);
v1 = zeros(size(fa_data,1)+size(B,2),4);
f1 = fa_data(:,2:(d+1));
f2 = fa_data(:,(d+2):end);

if length(cof) > 0
    bet = -cof;
    alp = [alp;bet];
    B = B';
    f1 = [f1;B(:,2:(d+1))];
    f2 = [f2;B(:,(d+2):end)];
end
v1(:,1) = rbf2(x1',f1,sigma);
v1(:,2) = rbf2(x2',f2,sigma);
v1(:,3) = -rbf2(x1',f2,sigma);
v1(:,4) = -rbf2(x2',f1,sigma);
v_t = repmat((sum(v1,2)),1,4);
v_t = v_t.*v1;

denom1 = (alp'*((v_t(:,1)+v_t(:,3)) ));
denom2 = (alp'*((v_t(:,2)+v_t(:,4)) ));
if denom1 == 0 || denom2 == 0
    dead = 1;
end

ra11 = (alp.*v_t(:,1) )/denom1;
ra12 = (alp.*v_t(:,3) )/denom1;
ra21 = (alp.*v_t(:,2) )/denom2;
ra22 = (alp.*v_t(:,4) )/denom2;

x1_f = f1;
x2_f = f2;

x1 = x1_f' * ra11+x2_f' * ra12;
x2 = x2_f' * ra21+x1_f' * ra22;
if sum(abs(x1)>20) || sum(abs(x2)>20)
    dead = 1;
end

v1(:,1) = rbf2(x1',f1,sigma);
v1(:,2) = rbf2(x2',f2,sigma);
v1(:,3) = -rbf2(x1',f2,sigma);
v1(:,4) = -rbf2(x2',f1,sigma);
beta = (alp'*((sum(v1,2)).^2 + 0.01))/(0.01+(2-2*rbf(x1,x2,sigma))^2);
end

% function [d_beta, d_x1, d_x2] = grad(beta,x1,x2,fa_data,fa,B,cof,sigma,t)
%     alp = fa.c .* fa.y/length(fa.c);
%     d = floor(size(fa_data,2)/2);
%     v1 = zeros(size(fa_data,1),4);
%     v1(:,1) = rbf2(x1',fa_data(:,2:(d+1)),sigma);
%     v1(:,2) = rbf2(x2',fa_data(:,(d+2):end),sigma);
%     v1(:,3) = -rbf2(x1',fa_data(:,(d+2):end),sigma);
%     v1(:,4) = -rbf2(x2',fa_data(:,2:(d+1)),sigma);
%
%     if length(cof) > 0
%         bet = cof;
%         v2 = zeros(size(B,2));
%         B = B';
%         v2(:,1) = rbf2(x1',B(:,2:(d+1)),sigma);
%         v2(:,2) = rbf2(x2',B(:,(d+2):end),sigma);
%         v2(:,3) = -rbf2(x1',B(:,(d+2):end),sigma);
%         v2(:,4) = -rbf2(x2',B(:,2:(d+1)),sigma);
%         v_B = bet' * ((sum(v2,2)).^2 + 1);
%     else
%         v_B = 0;
%     end
%
%     v = -rbf(x1,x2,sigma);
%
% %     d_beta = -2*alp'*((sum(v1,2)).^2 + 1) + 2*v_B  + 2*beta*(1+(2+2*v)^2);
% %     beta = beta + d_beta/(2*t);
%     d_beta = beta - (alp'*((sum(v1,2)).^2 + 1) - v_B)  / (beta*(1+(2+2*v)^2));
%     beta = beta - d_beta;
%    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     temp1 = (alp.*sum(v1,2)).*v1(:,1);
%     X11 = fa_data(:,2:(d+1)) - repmat(x1',size(fa_data,1),1);
%     v11 = X11'*temp1;
%     temp1 = (alp.*sum(v1,2)).*(-v1(:,3));
%     X21 = fa_data(:,(d+2):end) - repmat(x1',size(fa_data,1),1);
%     v21 = X21'*temp1;
%     v_1 = -2*2*beta*sigma*(v11+v21);
%
%     if length(B) > 0
%     temp1 = (bet.*sum(v2,2)).*v2(:,1);
%     X11 = B(:,2:(d+1)) - repmat(x1',size(B,1),1);
%     v11 = X11'*temp1;
%     temp1 = (bet.*sum(v2,2)).*(-v2(:,3));
%     X21 = B(:,(d+2):end) - repmat(x1',size(B,1),1);
%     v21 = X21'*temp1;
%     v_2 = 2*2*beta*sigma*(v11+v21);
%     else
%         v_2 = zeros(size(v_1));
%     end
%
%     v_3 = beta^2*sigma*(2*(2+2*v)*(-2)*v*(x2-x1));
%     d_x1 = (v_1+v_2+v_3)/t;
%     x1 = x1 - d_x1;
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%     temp1 = (alp.*sum(v1,2)).*v1(:,2);
%     X11 = fa_data(:,(d+2):end) - repmat(x2',size(fa_data,1),1);
%     v11 = X11'*temp1;
%     temp1 = (alp.*sum(v1,2)).*(-v1(:,4));
%     X21 = fa_data(:,2:(d+1)) - repmat(x2',size(fa_data,1),1);
%     v21 = X21'*temp1;
%     v_1 = -2*2*beta*sigma*(v11+v21);
%     if length(B) > 0
%     temp1 = (bet.*sum(v2,2)).*v2(:,2);
%     X11 = B(:,(d+2):end) - repmat(x2',size(B,1),1);
%     v11 = X11'*temp1;
%     temp1 = (bet.*sum(v2,2)).*(-v2(:,4));
%     X21 = B(:,2:(d+1)) - repmat(x2',size(B,1),1);
%     v21 = X21'*temp1;
%     v_2 = 2*2*beta*sigma*(v11+v21);
%     else
%         v_2 = zeros(size(v_1));
%     end
%
%     v_3 = beta^2*sigma*(2*(2+2*v)*(-2)*v*(x1-x2));
%     d_x2 = (v_1+v_2+v_3)/t;
%     x2 = x2 - d_x2;
% end

function [beta, x1, x2] = grad2(beta,x1,x2,fa_data,fa,B,cof,sigma,t)
alp = fa.c .* fa.y/length(fa.c);
d = floor(size(fa_data,2)/2);
v1 = zeros(size(fa_data,1)+size(B,2),4);
f1 = fa_data(:,2:(d+1));
f2 = fa_data(:,(d+2):end);

if length(cof) > 0
    bet = -cof;
    alp = [alp;bet];
    B = B';
    f1 = [f1;B(:,2:(d+1))];
    f2 = [f2;B(:,(d+2):end)];
end
v1(:,1) = rbf2(x1',f1,sigma);
v1(:,2) = rbf2(x2',f2,sigma);
v1(:,3) = -rbf2(x1',f2,sigma);
v1(:,4) = -rbf2(x2',f1,sigma);
v_t = repmat((sum(v1,2)),1,4);%%qi
v_tt = v_t.*v1;

p12 = 0.01 + (rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma))^2;
ra11 = 2*p12*(alp.*v_tt(:,1) );
ra12 = 2*p12*(alp.*v_tt(:,3) );

ra11_1 = 2*p12*(alp'*v_tt(:,1) );
ra12_1 = 2*p12*(alp'*v_tt(:,3) );
ra13_1 = (p12-0.01)*rbf(x1,x2,sigma)*(alp'*(0.01+v_t(:,1).^2));
denom1 = ra11_1 + ra12_1 + ra13_1;

ra21 = 2*p12*(alp.*v_tt(:,2));
ra22 = 2*p12*(alp.*v_tt(:,4));

ra21_2 = 2*p12*(alp'*v_tt(:,2));
ra22_2 = 2*p12*(alp'*v_tt(:,4));
ra23_2 = (p12-0.01)*rbf(x1,x2,sigma)*(alp'*(0.01+v_t(:,1).^2));
denom2 = ra21_2 + ra22_2 + ra23_2;

tempx1 = (f1'*ra11 + f2'*ra12 +  ra13_1*x2)/denom1;
tempx2 = (f2'*ra21 + f1'*ra22 +  ra23_2*x1)/denom2;

if sum(abs(tempx1)>20) || sum(abs(tempx2)>20)
    dead = 1;
end
x1 = tempx1;
x2 = tempx2;

v1(:,1) = rbf2(x1',f1,sigma);
v1(:,2) = rbf2(x2',f2,sigma);
v1(:,3) = -rbf2(x1',f2,sigma);
v1(:,4) = -rbf2(x2',f1,sigma);
beta = (alp'*((sum(v1,2)).^2 + 0.01))/(0.01+(rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma))^2);
end


function [beta, x1, x2] = grad4(beta,x1,x2,fa_data,fa,B,cof,sigma,t)
alp = fa.c .* fa.y/length(fa.c);
d = floor(size(fa_data,2)/2);
v1 = zeros(size(fa_data,1)+size(B,2),4);
f1 = fa_data(:,2:(d+1));
f2 = fa_data(:,(d+2):end);

s = 2;
sigm = 0.5;
be = 0.5;

if length(cof) > 0
    bet = -cof;
    alp = [alp;bet];
    B = B';
    f1 = [f1;B(:,2:(d+1))];
    f2 = [f2;B(:,(d+2):end)];
end
v1(:,1) = rbf2(x1',f1,sigma);
v1(:,2) = rbf2(x2',f2,sigma);
v1(:,3) = -rbf2(x1',f2,sigma);
v1(:,4) = -rbf2(x2',f1,sigma);
v_t = repmat((sum(v1,2)),1,4);%%qi
%     v_tt = v_t.*v1;
qi = v_t(:,1);
px = (rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      denom1 = 4*(alp'*(qi.^2))/(px)^3;
%      ra1 = px*(alp.*((qi)));
%      ra12 = (alp'*(qi.^2))*(x1-x2);
%      d_x1 = -(((f1'-f2')*ra1)-ra12)*denom1;
%
%      denom2 = 4*(alp'*(qi.^2))/(px)^3;
%      ra2 = px*(alp.*((qi)));
%      ra22 = (alp'*(qi.^2))*(x2-x1);
%      d_x2 = -(((f2'-f1')*ra2)-ra22)*denom2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
denom1 = 4*(alp'*(qi.^2))/(px)^3;
ra11 = px*(alp.*((qi).*v1(:,1)));
ra12 = px*(alp.*((qi).*v1(:,3)));
f11 = f1-repmat(x1',size(f1,1),1);
f12 = f2-repmat(x1',size(f2,1),1);
ra13 = rbf(x1,x2,sigma)*(alp'*(qi.^2))*(x1-x2);
d_x1 = -((f11'*ra11+f12'*ra12)-ra13)*denom1;

denom2 = 4*(alp'*(qi.^2))/(px)^3;
ra21 = px*(alp.*((qi).*v1(:,2)));
ra22 = px*(alp.*((qi).*v1(:,4)));
f21 = f2-repmat(x2',size(f1,1),1);
f22 = f1-repmat(x2',size(f2,1),1);
ra23 = rbf(x1,x2,sigma)*(alp'*(qi.^2))*(x2-x1);
d_x2 = -((f21'*ra21+f22'*ra22)-ra23)*denom2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
d_x = [d_x1;d_x2];

m = 0;
ft = (alp'*(qi.^2))^2/(px)^2;
while(1)

    tempx1 = be^m*s*d_x1 + x1;
    tempx2 = be^m*s*d_x2 + x2;
    v1_temp(:,1) = rbf2(tempx1',f1,sigma);
    v1_temp(:,2) = rbf2(tempx2',f2,sigma);
    v1_temp(:,3) = -rbf2(tempx1',f2,sigma);
    v1_temp(:,4) = -rbf2(tempx2',f1,sigma);

    qi_temp = sum(v1_temp,2);
    px_temp = (rbf(tempx1,tempx1,sigma)+rbf(tempx2,tempx2,sigma)-2*rbf(tempx1,tempx2,sigma));
    ft_1 = (alp'*(qi_temp.^2))^2/(px_temp)^2;;
    if ft-ft_1>= sigm*be^m*s*(d_x1'*d_x1+d_x2'*d_x2);
        break;
    end
    m = m + 1;
end
x1 = tempx1;
x2 = tempx2;

%      ra11 = 2*temp1*(alp.*((qi).*v1(:,1)));
%      ra12 = 2*temp1*(alp.*((qi).*v1(:,3)));
%      f11 = f1-repmat(x1',size(f1,1),1);
%      f12 = f2-repmat(x1',size(f2,1),1);
%      ra13_1 = (2*rbf(x1,x2,sigma))*(alp'*(qi.^2));
%      denom1 =  ra13_1;
%      x12 = (f11'*ra11+f12'*ra12)/denom1;
%      x1 = x12+x2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if sum(abs(x1)>20) || sum(abs(x2)>20)
    dead = 1;
end


v1(:,1) = rbf2(x1',f1,sigma);
v1(:,2) = rbf2(x2',f2,sigma);
v1(:,3) = -rbf2(x1',f2,sigma);
v1(:,4) = -rbf2(x2',f1,sigma);
beta = (alp'*((sum(v1,2)).^2 + 0.01))/(0.01+(rbf(x1,x1,sigma)+rbf(x2,x2,sigma)-2*rbf(x1,x2,sigma))^2);
end