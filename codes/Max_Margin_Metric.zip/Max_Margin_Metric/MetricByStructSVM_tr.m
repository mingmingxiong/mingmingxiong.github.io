function [M_r, b_r] = MetricByStructSVM_tr(X,Cs,C_svm,epsilon,M0,b0)
%X: n x d
%C_svm: 20
%epsilon: 0.05
%Cs: m x 3 (x1,x2, +/-1), m constraints
%[A] = MetricLearningByStructSVM(X,Cs,20,0.05);
if (~exist('A0')),
    A0 = eye(size(X,2));
end

X1 = X(Cs(:,1),:);
X2 = X(Cs(:,2),:);
X3 = X1-X2;

d = size(X,2);
H = [];
X_c = [];
%X = [];
X_b = [];
f0 = [];
f1 = [];
f = [];
xo = M0(:);
xo = [b0;xo];
%w = zeros(1+d^2,1);
M_r = M0;%zeros(d,d);
b_r = b0;
% C_svm = 20;
Xi = 1;
M = xo;

iterations = 0;

while(1)
   if(size(X_c,1)>0)
       A = ones(1,length(H));
       b = [C_svm];
       lb = zeros(length(H),1);
       ub = ones(length(H),1).*inf;
       % no starting point       
       Aeq = [];
       beq = [];
       % we need to tell the optimizer to use the medium scale version for this
       % problem formulation
       options = optimset('LargeScale','on','MaxIter',4000);
       x0 = [];
       [x,fval] = quadprog(H,f,A,b,Aeq,beq,lb,ub,x0,options);
       
       tol = 1e-8;
       x(find(x<=tol)) = 0;
       M = (X_c * x) + xo;
       b_r = M(1);
       M_r = reshape(M(2:end),d,d);
%        b = X_b' * x;
       Xi = (-f'*x - x'*H*x)/C_svm;
   end
   
%       %decompose M, make M >= 0
%       [V,D] = eigs(M,d/2);
%       D = D .* (D > 0);
%       M = V*D*V';
   
   c = zeros(size(X3,1),1);
   c1 = zeros(size(X3,1),1);
   X_c_temp = zeros(d,d);
   X_b_temp = 0;
   for i = 1:size(X3,1)
       c(i) = Cs(i,3)*(-X3(i,:)*M_r*X3(i,:)'+b_r);
       if c(i) <= 1
           c1(i) = 1;
           X_b_temp = X_b_temp + Cs(i,3);
           X_c_temp = X_c_temp + Cs(i,3)*(-X3(i,:)'*X3(i,:));
       end
   end
   
   if size(X_c,1)>0 && sum(c1)/size(X3,1)-c1'*c/size(X3,1) <= Xi+epsilon
%        %decompose M, make M >= 0
%       [V,D] = eigs(M,d/2);
%       D = D .* (D > 0);
%       M = V*D*V';
       break;
   end
   
   X_c_temp = [X_b_temp;X_c_temp(:)]/size(X3,1);
   X_c = [X_c X_c_temp];
   f0 = [f0;X_c_temp' * xo];
   f1 = [f;-sum(c1)/size(X3,1)]; 
   f = f0 + f1;
   H_plus = X_c' * X_c_temp;
   H = [H H_plus(1:end-1)];
   H = [H; H_plus'];
   
end
%decompose M, make M >= 0
[V,D] = eig(full(M_r));  %if dimension is large, don't do this
D = D .* (D > 0);
M_r = V*D*V';