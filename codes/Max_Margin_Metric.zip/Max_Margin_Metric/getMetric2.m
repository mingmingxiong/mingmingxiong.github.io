function [dis] = getMetric2(X1,X2,fa_hat,B,sigma)
%X1: n by d
dis = [];
nb = size(B,1);
d = floor(nb/2);
x3 = (B(2:(1+d),:))';
x4 = (B((2+d):end,:))';
for i = 1:size(X1,1)
    x1 = X1(i,:);
    x2 = X2(i,:);
    temp = (rbf2(x1,x3,sigma) + rbf2(x2,x4,sigma) - ...
        rbf2(x2,x3,sigma) - rbf2(x1,x4,sigma)).^2;
    temp = -fa_hat'*temp;
    dis = [dis temp];
end
end



function v = rbf2(x1,x2,sigma)
x1 = repmat(x1,size(x2,1),1);
 %v = exp(-sum((x1-x2).^2,2)*sigma);
  v = (sigma*sum(x1.*x1,2).*sum(x2.*x2,2));
%  v=v';
end

