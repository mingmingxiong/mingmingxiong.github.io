function [N_p,totalQ,ml,cl] = Explore_W(distW,labels,num,Q)

%data: n x d
%labels: n x 1
%num: the number of clusters
%Q: the allowed number of queries

%N_p: disjoint neighborhoods
%totalQ: the total number of queries in N_p

N_p = [];
queryP = [];
ml = [];cl = [];
totalQ = 1;
temp = struct;
temp.elements = ceil(rand(1)*size(distW,1));

queryP = [queryP;temp.elements];
N_p = [N_p;temp];
nbClusters = length(unique(labels));

while totalQ < Q && length(N_p) < num
    lens = [];
    for i = 1:size(queryP,1)
        templ = distW(:,queryP(i));
        lens = [lens templ];
    end
    v = min(lens,[],2);
    [v,ind] = max(v);
    
    queryP = [queryP;ind];
    signal = 1;
    for i = 1:length(N_p)
        if labels(ind)==labels(N_p(i).elements(1))
            N_p(i).elements = [N_p(i).elements ind];
            signal = 0;
            ml = [ml;[ind N_p(i).elements(1)]];
            break;
        else
            cl = [cl;[ind N_p(i).elements(1)]];
        end
    end
    if signal == 1
        temp = struct;
        temp.elements = ind;
        N_p = [N_p;temp];
    end
    totalQ = totalQ + i;
end