function [temparray] = ActiveQueryPairs(temp,W, Outputs, labels,NUMPOINTS,option)

% NUMPOINTS = 300;
temparray = [];
WEIGHT = 1;
if option == 1  %random samples
    querypointsx = round(size(W,1).*rand(NUMPOINTS,1)+0.5);
    querypointsx = querypointsx';
    querypointsy = round(size(W,1).*rand(NUMPOINTS,1)+0.5);
    querypointsy = querypointsy';
    for i = 1:NUMPOINTS
        tempx = 0;
        tempy = 0;
        if size(temp,1) > 0
        index = find(temp(:,1)==querypointsx(i));
        index1 = find(temp(index,2)==querypointsy(i));
        
        index = find(temp(:,1)==querypointsy(i));
        index2 = find(temp(index,2)==querypointsx(i));
        tempx = size(index1,1);
        tempy = size(index2,1);
        end
        if tempx ==0 & tempy ==0 & querypointsx(i) ~= querypointsy(i)
           temparray = [temparray;[querypointsx(i) querypointsy(i) labels(querypointsx(i))==labels(querypointsy(i))] WEIGHT];
           temparray = [temparray;[querypointsy(i) querypointsx(i) labels(querypointsx(i))==labels(querypointsy(i))] WEIGHT];
    
        end
    end
elseif option == 2 % fixed sample pairs
    querypointsx = round([1:30 40:80 120:140]);%round(size(W,1).*rand(NUMPOINTS,1)+0.5);
    querypointsx = querypointsx';
    querypointsy = round([50:80 140:180 180:200]);%round(size(W,1).*rand(NUMPOINTS,1)+0.5);
    querypointsy = querypointsy';
    for i = 1:size(querypointsx,1)
        tempx = 0;
        tempy = 0;
        if size(temp,1) > 0
        index = find(temp(:,1)==querypointsx(i));
        index1 = find(temp(index,2)==querypointsy(i));
        
        index = find(temp(:,1)==querypointsy(i));
        index2 = find(temp(index,2)==querypointsx(i));
        tempx = size(index1,1);
        tempy = size(index2,1);
        end
        if tempx ==0 & tempy ==0 & querypointsx(i) ~= querypointsy(i)
           temparray = [temparray;[querypointsx(i) querypointsy(i) labels(querypointsx(i))==labels(querypointsy(i))] WEIGHT];
        end
    end
elseif option == 3 % k maximal gradient loss
    temparray = [];
    for i = 1:59
        for j = i+1:60
            if i < 31 & j > 30
             temparray = [temparray;[i j 0 WEIGHT] ];
            else
             temparray = [temparray;[i j 1 WEIGHT] ];
            end
        end
    end
else
    temparray = [];
    disp(['There is no such option.\n']);
end