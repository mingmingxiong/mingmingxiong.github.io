function [data,size_cluster,labels] = build_scene(caseid)
% [data,size_cluster] = build_scene(case)
%
% case 1: random gaussian shaped blobs.
% case 2: one circular plus some gaussian blob, one inside, one outside 
% case 3: one circular plus some gaussian blob, one inside, two outside 
% Jianbo Shi, 1997

labels = [];
if caseid ==1,
  sigma_h = 2;
  sigma_v = 10;

  s_v = 10;
  s_h = 30;

  a = [sigma_h*randn(1,40);sigma_v*randn(1,40)];
  b = [s_h;s_v]*ones(1,50) + [sigma_h*randn(1,50);...
        sigma_v*randn(1,50)];

  data = [a,b];
  size_cluster = [40,50];
  labels = [ones(40,1);2*ones(50,1)];
elseif caseid == 2,
   num_cluster = 3;
   radius = 15;
   size_cluster = [80,10,10];
   labels = [ones(80,1);2*ones(10,1);3*ones(10,1)];
   raw_data = randn(2,sum(size_cluster));
   tmp = rand(2,size_cluster(1))-0.5;

   [t,idt] = sort(tmp(2,:));
   r_noise = 4;
   raw_data2 = [tmp(1,idt)*r_noise;...
             tmp(2,idt)*2];

   data = [(radius-raw_data2(1,1:size_cluster(1))).*...
        cos(pi*raw_data2(2,1:size_cluster(1)));...
        (radius-raw_data2(1,1:size_cluster(1))).*...
        sin(pi*raw_data2(2,1:size_cluster(1)))];

   
   center = [0,0];sig = [1,2];
   % size_cluster_base
   scb = size_cluster(1)+1;
   scb_next = scb+size_cluster(2)-1;
   data = [data,[center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)]];


   center = [radius+10,0]; sig = [1,1];
   scb = scb_next+1;
   scb_next = scb+size_cluster(3)-1;
   data = [data,[center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)]];
elseif caseid==3,
   num_cluster = 4;
   radius = 15;
   size_cluster = [80,10,20,20];
   %    labels = [ones(80,1);2*ones(10,1);3*ones(20,1);4*ones(20,1)];
   labels = [ones(80,1);2*ones(10,1);3*ones(40,1)];
   raw_data = randn(2,sum(size_cluster));
   tmp = rand(2,size_cluster(1))-0.5;

   [t,idt] = sort(tmp(2,:));
   r_noise = 4;
   raw_data2 = [tmp(1,idt)*r_noise;...
             tmp(2,idt)*2];

   data = [(radius-raw_data2(1,1:size_cluster(1))).*...
        cos(pi*raw_data2(2,1:size_cluster(1)));...
        (radius-raw_data2(1,1:size_cluster(1))).*...
        sin(pi*raw_data2(2,1:size_cluster(1)))];

   
   center = [0,0];sig = [1,2];
   % size_cluster_base
   scb = size_cluster(1)+1;
   scb_next = scb+size_cluster(2)-1;
   data = [data,[center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)]];


   center = [radius+25,8]; sig = [1,2.3];
   scb = scb_next+1;
   scb_next = scb+size_cluster(3)-1;
   data = [data,[center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)]];

   center = [radius+25,-6]; sig = [1.5,2.4];
   scb = scb_next+1;
   scb_next = scb+size_cluster(4)-1;
   data = [data,[center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)]];
elseif caseid == 4,
   size_cluster = [100,10,10];
   labels = [ones(100,1);2*ones(10,1);3*ones(10,1)];
   radius = 10;
   tmp = rand(2,size_cluster(1))-0.5;

   [t,idt] = sort(tmp(2,:));
   r_noise = 4;
   raw_data2 = [tmp(1,idt)*r_noise;...
             tmp(2,idt)*2];

   data = [(radius-raw_data2(1,1:size_cluster(1))).*...
        cos(pi*raw_data2(2,1:size_cluster(1)));...
        (radius-raw_data2(1,1:size_cluster(1))).*...
        sin(pi*raw_data2(2,1:size_cluster(1)))];

   
   result = zeros(1,size_cluster(1));

  % for j =1:size_cluster(1),
%	result(j) = sum(sum(A(1:j,1:j)))/j;
%   end
elseif caseid == 5,
  sigma_h = 0.1;
  sigma_v = 5;

  s_v = 10;
  s_h = 15;
  a_v = 10;
  a_h = 15;
  
  ar = -pi/4;
  br = pi/4;
  na = 100;
  nb = 100;
  a = [a_h;a_v]*ones(1,na) + [cos(ar) -sin(ar);sin(ar) cos(ar)]*[sigma_h*randn(1,na);...
      sigma_v*randn(1,na)];
  b = [s_h;s_v]*ones(1,nb) + [cos(br) -sin(br);sin(br) cos(br)]*[sigma_h*randn(1,nb);...
        sigma_v*randn(1,nb)];
  
  data = [a,b];
  size_cluster = [na,nb];
  labels = [ones(na,1);2*ones(nb,1)];
elseif caseid == 6
    load im.mat
elseif caseid == 7,
  sigma_h = 0.1;
  sigma_v = 5;

  s_v = 10;
  s_h = 10;
  a_v = 15;
  a_h = 20;
  
  ar = -pi/3;
  br = pi/3;
  na = 100;
  nb = 100;
  a = [a_h;a_v]*ones(1,na) + [cos(ar) -sin(ar);sin(ar) cos(ar)]*[sigma_h*randn(1,na);...
      sigma_v*randn(1,na)];
  b = [s_h;s_v]*ones(1,nb) + [cos(br) -sin(br);sin(br) cos(br)]*[sigma_h*randn(1,nb);...
        sigma_v*randn(1,nb)];
  
  data = [a,b];
  size_cluster = [na,nb];
  labels = [ones(na,1);2*ones(nb,1)];
elseif caseid == 8,
  sigma_h = 0;
  sigma_v = 1;

   s_v = 0;
  s_h = 0;
  a_v = 0;
  a_h = 0;
  
  ar = -pi/4;
  br = pi/4;
  na = 30;
  nb = 30;
  ay = sigma_v*rand(1,na);
  [ay,ina] = sort(ay);
  a = [a_h;a_v]*ones(1,na) + [cos(ar) -sin(ar);sin(ar) cos(ar)]*[sigma_h*rand(1,na);...
      ay];
  
  by = sigma_v*rand(1,nb);
  [by,inb] = sort(by);
  b = [s_h;s_v]*ones(1,nb) + [cos(br) -sin(br);sin(br) cos(br)]*[sigma_h*rand(1,nb);...
        by];
  
    
  
  data = [a,b];
  size_cluster = [na,nb];
  labels = [ones(na,1);2*ones(nb,1)];
elseif caseid == 9,
  sigma_h = 0;
  sigma_v = 1;

  s_v = 0;
  s_h = 0;
  a_v = 0;
  a_h = 0;
  
  ar = -pi/4;
  br = pi/4;
  na = 100;
  nb = 100;
  a = [a_h;a_v]*ones(1,na) + [cos(ar) -sin(ar);sin(ar) cos(ar)]*[sigma_h*rand(1,na);...
      sigma_v*rand(1,na)-0.2];
  b = [s_h;s_v]*ones(1,nb) + [cos(br) -sin(br);sin(br) cos(br)]*[sigma_h*rand(1,nb);...
        sigma_v*rand(1,nb)-0.15];
  
  data = [a,b];
  size_cluster = [na,nb];
  labels = [ones(na,1);2*ones(nb,1)];
elseif caseid == 10,
  sigma_h = 0;
  sigma_v = 1;

   s_v = 0;
  s_h = 0;
  a_v = 0;
  a_h = 0;
  
  ar = -pi/4;
  br = pi/4;
  cr = -5*pi/4;
  dr = 5*pi/4;
  na = 30;
  nb = 30;
  ay = sigma_v*rand(1,na);
  [ay,ina] = sort(ay);
  a = [a_h;a_v]*ones(1,na) + [cos(ar) -sin(ar);sin(ar) cos(ar)]*[sigma_h*rand(1,na);...
      ay];
  c = [a_h;a_v]*ones(1,na) + [cos(cr) -sin(cr);sin(cr) cos(cr)]*[sigma_h*rand(1,na);...
      ay];
  by = sigma_v*rand(1,nb);
  [by,inb] = sort(by);
  b = [s_h;s_v]*ones(1,nb) + [cos(br) -sin(br);sin(br) cos(br)]*[sigma_h*rand(1,nb);...
        by];
  d = [s_h;s_v]*ones(1,nb) + [cos(dr) -sin(dr);sin(dr) cos(dr)]*[sigma_h*rand(1,nb);...
        by];
    
  
  data = [a,b,c,d];
  size_cluster = [na+nb,na+nb];
  labels = [ones(na+nb,1);2*ones(na+nb,1)];
elseif caseid == 11,
    a = 0.1*[-5:5;zeros(1,11)];
    b = 0.1*[zeros(1,11);-5:5]+0.05;
    data = [a,b];
    size_cluster = [11,11];
    labels = [ones(11,1);2*ones(11,1)];
elseif caseid == 12,
    a = 0.05*[-15:-1,1:15;zeros(1,30)];
    b = 0.05*[zeros(1,30);-15:-1,1:15];
    data = [a,b];
    size_cluster = [30,30];
    labels = [ones(30,1);2*ones(30,1)];
elseif caseid == 13,
    a = 0.05*[-15:-1,1:15;zeros(1,30)];
    b = 0.05*[zeros(1,30);-15:-1,1:15];
    data = [a,b];
    size_cluster = [30,30];
    labels = [ones(30,1);2*ones(30,1)];
elseif caseid==14,
   num_cluster = 4;
   
   size_cluster = [70,70,70,70];
% labels = [ones(size_cluster(1)+size_cluster(2),1);2*ones(size_cluster(3),1);3*ones(size_cluster(4),1)];
labels = [ones(size_cluster(1),1);2*ones(size_cluster(2),1);3*ones(size_cluster(3)+size_cluster(4),1)];   
raw_data = 0.5*randn(2,sum(size_cluster));
   
   center = [0,0];sig=[1,1];
   scb = 1; scb_next = size_cluster(1);
   data = [center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)];

   
   center = [0,2.0];sig = [1,1];
   % size_cluster_base
   scb = size_cluster(1)+1;
   scb_next = scb+size_cluster(2)-1;
   data = [data,[center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)]];


   center = [2.25,0];sig = [1,1];
   % size_cluster_base
   scb = size_cluster(2)+1;
   scb_next = scb+size_cluster(3)-1;
   data = [data,[center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)]];

   center = [2.7,2.0];sig = [1,1];
   % size_cluster_base
   scb = size_cluster(3)+1;
   scb_next = scb+size_cluster(4)-1;
   data = [data,[center(1)+sig(1)*raw_data(1,scb:scb_next);...
                center(2)+sig(2)*raw_data(2,scb:scb_next)]];
end
