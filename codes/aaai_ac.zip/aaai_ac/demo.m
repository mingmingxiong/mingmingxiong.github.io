load sonar2.mat

[errt,qryt] = ActiveClustering_aaai(dist_sonar, la_sonar,2,1);