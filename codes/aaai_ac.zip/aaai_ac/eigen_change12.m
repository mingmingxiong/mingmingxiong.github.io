function change = eigen_change12(old_N_p,eigenvector, eigenvalue,Ind, nCluster)

inds = [];
for i = 1:length(old_N_p)
    temp = old_N_p(i).elements(1);
    inds = [inds; temp];
end
length(inds)
eigenvalue = eigenvalue(:);

tot = size(eigenvector,1);
change = zeros(length(Ind),1);


%  tic
tmp_v = repmat(eigenvalue(2:nCluster)',length(eigenvalue),1)-repmat(eigenvalue,1,nCluster-1);
tmp_v(tmp_v==0) = 1e-16;


for ii = 1:length(Ind)
    i = Ind(ii);
    temp = 0;
    
    for j = 1:length(inds)
       ei = zeros(tot,1);
       ei(i) = 1;
       ej = zeros(tot,1);
       ej(inds(j)) = 1;
%        tmp_matrix = (eigenvector'*(ei-ej));
%        tmp_matrix = tmp_matrix(1:nCluster,:)*tmp_matrix';
    
%        tic
%        for k = 2:size(tmp_matrix,1)
%            tmp_row = tmp_matrix(k,:);
%            tmp_row(1) = 0;
%            tmp_row(k) = 0;
%            tmp_v = eigenvalue(k)-eigenvalue;
%            tmp_v(tmp_v==0) = 1e-16;
%            tmp_row = tmp_row'./tmp_v;
%            tmp_row = repmat(tmp_row,1,length(Ind));
%            tmp = tmp_row.*eigenvector(Ind,:)';
%            tmp = sum(tmp,1);
%            tmp = sum(tmp.^2);
%            temp = temp + tmp;
%        end
%        toc
    
       
 
      
       tmp_matrix = (eigenvector'*(ei-ej));
       tmp_matrix = tmp_matrix*tmp_matrix';  
       tmp_matrix = tmp_matrix-diag(diag(tmp_matrix));
      
       tmp_row = tmp_matrix(1:nCluster,:);
       tmp_row = tmp_row(2:end,:);
       tmp_row(:,1) = 0;      
       tmp_row = tmp_row'./tmp_v;
       tmp_row = repmat(tmp_row,[1 1 length(Ind)]);
       
       tmp_row = permute(tmp_row,[1 3 2]);
       tmp1 = repmat(eigenvector(Ind,:)',[1 1 nCluster-1]);
       tmp = tmp_row.*tmp1;
       tmp = sum(tmp,1);
       tmp = tmp.^2;
       temp = temp + sum(tmp(:));
      
    %   toc
       
    end
    
    change(ii) = temp;
end