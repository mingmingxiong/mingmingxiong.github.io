function [errt,qryt] = ActiveClustering_aaai(distW, labelfeatures,nbCluster,weight)

temp = randperm(size(distW,1));
distW = distW(temp,temp);
labelfeatures = double(labelfeatures(temp));

temp_d = diag(distW);
distW = distW-diag(temp_d);

[N_p,totalQ] = Explore_W(distW,labelfeatures,nbCluster,2);

tot = size(distW,1);

indpo = [];
for tempi = 1:length(N_p)
    temp = N_p(tempi).elements;
    indpo = [indpo;temp(:)];
end
errt = [];
qryt = [];


%build knn graph
fnn = 21;

[dists result ] = sort(distW,1);

result = result(1:fnn,:);
dists = dists(1:fnn,:);
result_n = result(2:fnn,:);

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% evaluate the variance
r = mean(dists(:));
t1 = linspace(1/10,1,5);
t2 = linspace(1,10,5);
t = [t1,t2(2:end)];
sigmas = r;

err = [];
qry = [];
sigm = 1/sigmas;
Sim1 = exp(-(distW*sigm).^2/2);
Sim2 = exp(-(distW*sigm).^2/2);
Sim = exp(-(dists*sigm).^2/2);
tempx = 1:tot;
xresult = repmat(tempx,size(result,1),1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tempxresult = xresult(:);

sparSim = sparse(xresult(:),result(:),Sim(:),tot,tot);
W = (Sim1+Sim1')/2;
%%
total_index = 1:size(W,1);
total_index = total_index(:);

num_query = totalQ;
if tot > 490
    tot1 = 490;
else
    tot1 = tot-20;
end

ii_i = 1;

while ii_i < tot1
    ii_i = ii_i + 1
    tic
    sparSim = (sparSim+sparSim')/2;%(Sim1+Sim1')/2;%(sparSim+sparSim')/2;
    [NcutDiscrete,output,NcutEigenvalues, U] = ncutW(sparSim,nbCluster);
    
    Outputs = zeros(size(sparSim,1),1);
    for ii = 1:nbCluster
        ind = find(NcutDiscrete(:,ii)==1);
        Outputs(ind) = ii;
    end
    
    goldla = unique(labelfeatures);%c
    resla = unique(Outputs); %k
    comatrix = zeros(length(resla),length(goldla)); %k by c
    for i = 1:size(comatrix,1)
        co_i = find(Outputs==resla(i));
        for j = 1:size(comatrix,2)
            co_j = find(labelfeatures == goldla(j));
            c_intersect = intersect(co_i,co_j);
            comatrix(i,j) = length(c_intersect);
        end
    end
    [v,hc,hk,h_ck,h_kc] = calculate_v_measure (comatrix);
    RI = v;
    [AR,RI1,MI,HI]=valid_RandIndex(Outputs,labelfeatures);
    [jcc] = cmp_jcc(Outputs,labelfeatures);
    err = [err [RI; RI1; jcc] ];
    [RI; RI1; jcc]
    qry = [qry num_query];
    RI;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%one by one
    entropy = zeros(tot,1);
    for ii=1:tot
        count = zeros(nbCluster,1);
        temp = Outputs(result_n(:,ii));
        for j = 1:length(temp)
            count(temp(j)) = count(temp(j)) + 1;
        end
        count = count/sum(count);
        temp1 = unique(temp);
        for temp_i = 1:length(temp1)
            temp_p = sum(temp1(temp_i)==temp)/length(temp);
            entropy(ii) = entropy(ii) - temp_p *log(temp_p);
        end
        %entropy(ii) = 1-sum(temp==Outputs(ii))/length(temp);
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    entropy1 = entropy + 1e-16;
    entropy1(indpo) = -1;
    
    
    if length(entropy1) >100
        [~,Ind] = sort(entropy1,'descend');
        if length(entropy1)-length(indpo) > 100
            Ind = Ind(1:100);
        else
            Ind = Ind(1:(length(entropy1)-length(indpo)));
        end
        temp_entropy = entropy1(Ind);
    else
        temp_entropy = entropy1;
        Ind = 1:length(entropy1);
    end
    
    
    Lap = diag(sparSim*ones(size(sparSim,1),1))-sparSim;
    
    
    if size(sparSim,1)-1 < floor(1.6*nbCluster)
        [eigenVe,eigenVa] = eigs(Lap,size(sparSim,1)-1,'SA');
    else
        [eigenVe,eigenVa] = eigs(Lap,floor(1.6*nbCluster),'SA');
    end
    toc
    tic
    change = eigen_change12(N_p,eigenVe, diag(eigenVa),Ind,nbCluster);
    toc
    
    temp_entropy = (temp_entropy).* change;
    
    
    
    [Y,index] = max(temp_entropy);
    index = Ind(index);
    
    
    indpo = [indpo;index];
    
    
    tic
    [N_p,h,ML,CL] = Consolidate_single_W(distW,labelfeatures,N_p,index);
    
    num_query = num_query + h;
    
    for i = 1:size(ML,1)
        sparSim(ML(i,1),ML(i,2)) = weight;%20;
        sparSim(ML(i,2),ML(i,1)) = weight;%20;
        Sim1(ML(i,1),ML(i,2)) = weight;%20;
        Sim1(ML(i,2),ML(i,1)) = weight;%20;
    end
    for i = 1:size(CL,1)
        sparSim(CL(i,1),CL(i,2)) = -weight;%-20;
        sparSim(CL(i,2),CL(i,1)) = -weight;%-20;
        Sim1(CL(i,1),CL(i,2)) = -weight;%-20;
        Sim1(CL(i,2),CL(i,1)) = -weight;%-20;
    end
    toc
end
errt = [errt;err];
qryt = [qryt;qry];

end


