load uciml.mat
[acc] = CrossValidateKNN_RFD(la_sonar, da_sonar,  5, 5,1000);