load alldata.mat

acc = ActiveSpectral(da_sonar, la_sonar, 20,2);

%acc is v-measure value for each iteration, the number of constraint for
%each iteration is the number of neighbor points for kNN graph