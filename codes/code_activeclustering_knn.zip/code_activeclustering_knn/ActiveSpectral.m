function acc = ActiveSpectral(features, labelfeatures, nn,nbCluster)

% errt = ActiveSpectral(da_sonar, la_sonar, 20,2);
%features: n x k, n is the number of data points
%labelfeatures: n x 1 vector
%nn: the number of neighbor points for kNN graph
%nbCluster: cluster number

%acc: V-measure value for accuracy, the larger, the better

%loopnum: the number of active process

%used the self-tune idea

addpath('svm-matlab/common_files');
%addpath('flann');
%addpath('KPMstats');
%addpath('clustering_evaluation_code');

results = [];
loopnum = 1;
M = eye(size(features,2));
tot = size(features,1);
pairs = [];
pairs_prop = [];
indpo = [];
acc = [];
for i_t =1:loopnum
    features1 = features*sqrtm(M);
%%   
    %build knn graph
    fnn = nn + 1;
    [result dists] = kNearestNeighbors(features1, features1, fnn);
    result = result'; dists = dists';
    result_n = result(2:fnn,:);
  
%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% evaluate the variance
    r = mean(dists(:));
    t1 = linspace(1/10,1,5);
    t2 = linspace(1,10,5);
    t = [t1,t2(2:end)];
    sigmas = t * r;
    sigmas = r;
   
    acc_temp = [];
    sigm = 1/sigmas;

    Sim = exp(-(dists*sigm).^2/2);
    tempx = 1:tot;
    xresult = repmat(tempx,size(result,1),1);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    tempxresult = xresult(:);
    tempresult = result;
    tempSim = Sim(:);
    labelpairs = (labelfeatures(tempxresult)>-1000);
    temporder = randperm(tot);
    ncp = [];
    sparSim = sparse(xresult(:),result(:),Sim(:),tot,tot);
    for ii_i = 1:tot
        sparSim = (sparSim+sparSim')/2;
        [NcutDiscrete,output,NcutEigenvalues, U] = ncutW(sparSim,nbCluster);

        Outputs = zeros(size(sparSim,1),1);
        for ii = 1:nbCluster
            index = find(NcutDiscrete(:,ii)==1);
            Outputs(index) = ii;
        end
       
      	goldla = unique(labelfeatures);%c
		resla = unique(Outputs); %k
		comatrix = zeros(length(resla),length(goldla)); %k by c
		for i = 1:size(comatrix,1)
		   co_i = find(Outputs==resla(i));
		   for j = 1:size(comatrix,2)
               co_j = find(labelfeatures == goldla(j));
			   c_intersect = intersect(co_i,co_j);
			   comatrix(i,j) = length(c_intersect);
		   end
		end
		[v,hc,hk,h_ck,h_kc] = calculate_v_measure (comatrix);
										           
        acc_temp = [acc_temp v];
        v
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%one by one
        entropy = zeros(tot,1);
        for ii=1:tot
            count = zeros(nbCluster,1);
            temp = Outputs(result_n(:,ii));
            for j = 1:length(temp)
                count(temp(j)) = count(temp(j)) + 1;
            end
            count = count/sum(count);
            entropy(ii) = 1-sum(temp==Outputs(ii))/length(temp);           
        end

        %     %choose the maximum entropy point
        entropy = entropy + 1e-10;
        entropy(indpo) = -1;
        [Y,index] = max(entropy);        
        indpo = [indpo;index];
        
        pairstemp = [];       
        pairstemp1 = [];
        for ii = 1:length(result_n(:,index))
            if labelfeatures(index) ~= labelfeatures(result_n(ii,index)) %&& ...

                pairstemp = [ pairstemp;[index result_n(ii,index) -1 0] ];
                pairstemp1 = [ pairstemp1;[index result_n(ii,index) -1 0] ];
                sparSim(index, result_n(ii,index)) = 0;
                sparSim(result_n(ii,index), index) = 0;
            else
                pairstemp1 = [ pairstemp1;[index result_n(ii,index) 1 0] ];
                sparSim(index, result_n(ii,index)) = 1;
                sparSim(result_n(ii,index), index) = 1;
            end
        end
        
        pairs = [pairs;pairstemp];

        pairs_prop = [pairs_prop;pairstemp1];
        if size(pairs,1) > 0
            [unip,unin] = unique(pairs(:,1:2),'rows'); %sometimes needs to be commented, some not        pairs = pairs(unin,:);
            [unip_prop,unin_prop] = unique(pairs_prop(:,1:2),'rows');
            pairs = pairs(unin,:);           
        end        
    end
    acc = [acc;acc_temp];

end

function Wt = affinitypropa(pairs,Neighbors,alpha,k)
%Wt = (1-alpha)*W + alpha*P*Wt_1  0<alpha<1, it converges to:
W = zeros(size(Neighbors,2));
P = zeros(size(Neighbors,2));
for i = 1:size(pairs,1)
    W(pairs(i,1),pairs(i,2)) = pairs(i,3);
    W(pairs(i,2),pairs(i,1)) = pairs(i,3);
end
for i = 1:size(Neighbors,2)
    P(i,Neighbors(:,i)) = 1/k;
    W(i,i) = 1;
end
Wt = (1-alpha)*((eye(size(P,1))-alpha*P)^(-1))*W;
%  sum(sum(W<0.*(Wt<-0.6)>0)) - sum(sum(W<0))
sum(sum((W>0.*(Wt<-0.6))>0))